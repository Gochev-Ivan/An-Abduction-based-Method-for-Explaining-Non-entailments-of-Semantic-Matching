package com.xai.methods;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.javatuples.Pair;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;
import org.graphstream.ui.layout.HierarchicalLayout;

import com.xai.methods.DescriptionTree;

import Trees.DTNode;

public class TestClass_1 {
	
	public static Pair<DescriptionTree, DescriptionTree> Eq_1() {
		DescriptionTree T1 = new DescriptionTree('v');
		
		LinkedList<String> label_v = new LinkedList<String>();
		label_v.add("A");
		label_v.add("B");
		label_v.add("C");
		LinkedList<String> label_u = new LinkedList<String>();
		label_u.add("D");
		label_u.add("E");
		label_u.add("F");
		
		// Change label_v and label_u - they are all the same in memory - define them separately.
		
		LinkedList<String> label_v1 = new LinkedList<String>();
		label_v1.add("A");
//		label_v1.add("B");
//		label_v1.add("C");
		LinkedList<String> label_u1 = new LinkedList<String>();
		label_u1.add("D");
//		label_u1.add("E");
//		label_u1.add("F");
		T1.addEdge(0, 1, 'r', label_v1, label_u1);
		
		LinkedList<String> label_v11 = new LinkedList<String>();
		label_v11.add("A");
//		label_v11.add("B");
//		label_v11.add("C");
		LinkedList<String> label_u11 = new LinkedList<String>();
		label_u11.add("D");
//		label_u11.add("E");
//		label_u11.add("F");
		T1.addEdge(0, 2, 's', label_v11, label_u11);
		
		LinkedList<String> label_v111 = new LinkedList<String>();
		label_v111.add("A");
//		label_v111.add("B");
//		label_v111.add("C");
		LinkedList<String> label_u111 = new LinkedList<String>();
		label_u111.add("D");
//		label_u111.add("E");
//		label_u111.add("F");
		T1.addEdge(0, 3, 'r', label_v111, label_u111);
		
		LinkedList<String> label_v1111 = new LinkedList<String>();
		label_v1111.add("A");
//		label_v1111.add("B");
//		label_v1111.add("C");
		LinkedList<String> label_u2222 = new LinkedList<String>();
		label_u2222.add("D");
//		label_u2222.add("E");
//		label_u2222.add("F");
		T1.addEdge(0, 4, 'r', label_v1111, label_u2222);
		
		LinkedList<String> label_v111111 = new LinkedList<String>();
		label_v111111.add("A");
//		label_v111111.add("B");
//		label_v111111.add("C");
		LinkedList<String> label_u111111 = new LinkedList<String>();
		label_u111111.add("D");
//		label_u111111.add("E");
//		label_u111111.add("F");
		T1.addEdge(1, 5, 'r', label_v111111, label_u111111);
		
		LinkedList<String> label_v1111111 = new LinkedList<String>();
		label_v1111111.add("A");
//		label_v1111111.add("B");
//		label_v1111111.add("C");
		LinkedList<String> label_u1111111 = new LinkedList<String>();
		label_u1111111.add("D");
//		label_u1111111.add("E");
//		label_u1111111.add("F");
		T1.addEdge(1, 6, 's', label_v1111111, label_u1111111);
		
		LinkedList<String> label_v11111111 = new LinkedList<String>();
		label_v11111111.add("A");
//		label_v11111111.add("B");
//		label_v11111111.add("C");
		LinkedList<String> label_u11111111 = new LinkedList<String>();
		label_u11111111.add("D");
//		label_u11111111.add("E");
//		label_u11111111.add("F");
		T1.addEdge(2, 7, 's', label_v11111111, label_u11111111);
		
		LinkedList<String> label_v111111111 = new LinkedList<String>();
		label_v111111111.add("A");
//		label_v111111111.add("B");
//		label_v111111111.add("C");
		LinkedList<String> label_u111111111 = new LinkedList<String>();
		label_u111111111.add("D");
//		label_u111111111.add("E");
//		label_u111111111.add("F");
		T1.addEdge(3, 8, 's', label_v111111111, label_u111111111);
		
		LinkedList<String> label_v2 = new LinkedList<String>();
		label_v2.add("A");
//		label_v2.add("B");
//		label_v2.add("C");
		LinkedList<String> label_u2 = new LinkedList<String>();
		label_u2.add("D");
//		label_u2.add("E");
//		label_u2.add("F");
		T1.addEdge(4, 9, 's', label_v2, label_u2);
		
		LinkedList<String> label_v3 = new LinkedList<String>();
		label_v3.add("A");
//		label_v3.add("B");
//		label_v3.add("C");
		LinkedList<String> label_u3 = new LinkedList<String>();
		label_u3.add("D");
//		label_u3.add("E");
//		label_u3.add("F");
		T1.addEdge(5, 10, 'r', label_v3, label_u3);
		
		LinkedList<String> label_v4 = new LinkedList<String>();
		label_v4.add("A");
//		label_v4.add("B");
//		label_v4.add("C");
		LinkedList<String> label_u4 = new LinkedList<String>();
		label_u4.add("D");
//		label_u4.add("E");
//		label_u4.add("F");
		T1.addEdge(5, 11, 'r', label_v4, label_u4);
		
		LinkedList<String> label_v5 = new LinkedList<String>();
		label_v5.add("A");
//		label_v5.add("B");
//		label_v5.add("C");
		LinkedList<String> label_u5 = new LinkedList<String>();
		label_u5.add("D");
//		label_u5.add("E");
//		label_u5.add("F");
		T1.addEdge(6, 12, 'r', label_v5, label_u5);
		
		LinkedList<String> label_v6 = new LinkedList<String>();
		label_v6.add("A");
//		label_v6.add("B");
//		label_v6.add("C");
		LinkedList<String> label_u6 = new LinkedList<String>();
		label_u6.add("D");
//		label_u6.add("E");
//		label_u6.add("F");
		T1.addEdge(6, 13, 's', label_v6, label_u6);
		
		LinkedList<String> label_v7 = new LinkedList<String>();
		label_v7.add("A");
//		label_v7.add("B");
//		label_v7.add("C");
		LinkedList<String> label_u8 = new LinkedList<String>();
		label_u8.add("D");
//		label_u8.add("E");
//		label_u8.add("F");
		T1.addEdge(8, 14, 'p', label_v7, label_u8);
		
		DescriptionTree T2 = new DescriptionTree('w');
		
		LinkedList<String> label_w1 = new LinkedList<String>();
		label_w1.add("A");
//		label_w1.add("B");
//		label_w1.add("C");
		LinkedList<String> label_q1 = new LinkedList<String>();
		label_q1.add("D");
//		label_q1.add("E");
//		label_q1.add("F");
		T2.addEdge(0, 1, 'r', label_w1, label_q1);
		
		LinkedList<String> label_w2 = new LinkedList<String>();
		label_w2.add("A");
//		label_w2.add("B");
//		label_w2.add("C");
		LinkedList<String> label_q2 = new LinkedList<String>();
		label_q2.add("D");
//		label_q2.add("E");
//		label_q2.add("F");
		T2.addEdge(0, 2, 's', label_w2, label_q2);

		LinkedList<String> label_w3 = new LinkedList<String>();
		label_w3.add("A");
//		label_w3.add("B");
//		label_w3.add("C");
		LinkedList<String> label_q3 = new LinkedList<String>();
		label_q3.add("D");
//		label_q3.add("E");
//		label_q3.add("F");
		T2.addEdge(0, 3, 'r', label_w3, label_q3);
		
		LinkedList<String> label_w4 = new LinkedList<String>();
		label_w4.add("A");
//		label_w4.add("B");
//		label_w4.add("C");
		LinkedList<String> label_q4 = new LinkedList<String>();
		label_q4.add("D");
//		label_q4.add("E");
//		label_q4.add("F");
		T2.addEdge(0, 4, 's', label_w4, label_q4);
		
		LinkedList<String> label_w5 = new LinkedList<String>();
		label_w5.add("A");
//		label_w5.add("B");
//		label_w5.add("C");
		LinkedList<String> label_q5 = new LinkedList<String>();
		label_q5.add("D");
//		label_q5.add("E");
//		label_q5.add("F");
		T2.addEdge(1, 5, 'r', label_w5, label_q5);
		
		LinkedList<String> label_w6 = new LinkedList<String>();
		label_w6.add("A");
//		label_w6.add("B");
//		label_w6.add("C");
		LinkedList<String> label_q6 = new LinkedList<String>();
		label_q6.add("D");
//		label_q6.add("E");
//		label_q6.add("F");
		T2.addEdge(1, 6, 's', label_w6, label_q6);
		
		LinkedList<String> label_w7 = new LinkedList<String>();
		label_w7.add("A");
//		label_w7.add("B");
//		label_w7.add("C");
		LinkedList<String> label_q7 = new LinkedList<String>();
		label_q7.add("D");
//		label_q7.add("E");
//		label_q7.add("F");
		T2.addEdge(3, 7, 's', label_w7, label_q7);
		
		LinkedList<String> label_w8 = new LinkedList<String>();
		label_w8.add("A");
//		label_w8.add("B");
//		label_w8.add("C");
		LinkedList<String> label_q8 = new LinkedList<String>();
		label_q8.add("D");
//		label_q8.add("E");
//		label_q8.add("F");
		T2.addEdge(4, 8, 's', label_w8, label_q8);
		
		LinkedList<String> label_w9 = new LinkedList<String>();
		label_w9.add("A");
//		label_w9.add("B");
//		label_w9.add("C");
		LinkedList<String> label_q9 = new LinkedList<String>();
		label_q9.add("D");
//		label_q9.add("E");
//		label_q9.add("F");
		T2.addEdge(5, 9, 'r', label_w9, label_q9);
		
		LinkedList<String> label_w10 = new LinkedList<String>();
		label_w10.add("A");
//		label_w10.add("B");
//		label_w10.add("C");
		LinkedList<String> label_q10 = new LinkedList<String>();
		label_q10.add("D");
//		label_q10.add("E");
//		label_q10.add("F");
		T2.addEdge(5, 10, 'r', label_w10, label_q10);
		
		LinkedList<String> label_w11 = new LinkedList<String>();
		label_w11.add("A");
//		label_w11.add("B");
//		label_w11.add("C");
		LinkedList<String> label_q11 = new LinkedList<String>();
		label_q11.add("D");
//		label_q11.add("E");
//		label_q11.add("F");
		T2.addEdge(7, 11, 'p', label_w11, label_q11);
		
		LinkedList<String> label_w12 = new LinkedList<String>();
		label_w12.add("A");
//		label_w12.add("B");
//		label_w12.add("C");
		LinkedList<String> label_q12 = new LinkedList<String>();
		label_q12.add("D");
//		label_q12.add("E");
//		label_q12.add("F");
		T2.addEdge(8, 12, 's', label_w12, label_q12);
		
		Pair<DescriptionTree, DescriptionTree> DTs = new Pair<DescriptionTree, DescriptionTree>(T1, T2);
		
		return DTs;
	}
	
	public static void displayTrees(DescriptionTree T1, DescriptionTree T2) {
		// ==============================================================================================================
				Graph graph_T1 = new SingleGraph("T1");
				
//				graph_T1.setStrict(false);
//				graph_T1.setAutoCreate(false);
				
				graph_T1.setAttribute("ui.stylesheet", "node{\n" +
		                "    size: 10px, 10px;\n" +
		                "    fill-color: #e6b400;\n" +
		                "    text-mode: normal; \n" +
		                "}" + "edge{\n" +
						"    text-offset: -10,-10;\n" +
						"    text-alignment:above;\n" +
		                "    fill-color: #4169e1;\n" +
		                "    text-mode: normal; \n" +
		                "}" + "node#0 {\r\n" + 
		        		"	fill-color: #08a045;\r\n" + "}" + "node:clicked {\r\n" + "	fill-color: red;\r\n" + "}"
		                + "graph {\r\n"
		        		+ "	fill-color: lightgray;\r\n"
		        		+ "}");
				
				for (Entry<Integer, DTNode> entry : T1.V.entrySet()) {
					DTNode node = entry.getValue();
					graph_T1.addNode(entry.getKey().toString()).setAttribute("ui.label", node.name);
				}
				
				int edge_counter = 0;
				for (Entry<Pair<Integer, Integer>, Character> entry : T1.E.entrySet()) {
					Pair<Integer, Integer> edge = entry.getKey();
					
					String node_v = edge.getValue0().toString();
					String node_u = edge.getValue1().toString();
					String edge_label = entry.getValue().toString();
					
					graph_T1.addEdge(edge_label + "(" + edge_counter + ")", node_v, node_u, true).setAttribute("ui.label", edge_label);
					edge_counter++;
				}
				// ==============================================================================================================
				
				// ==============================================================================================================
				Graph graph_T2 = new SingleGraph("T2");
				
				graph_T2.setAttribute("ui.stylesheet", "node{\n" +
		                "    size: 10px, 10px;\n" +
		                "    fill-color: #e6b400;\n" +
		                "    text-mode: normal; \n" +
		                "}" + "edge{\n" +
						"    text-offset: -10,-10;\n" +
						"    text-alignment:above;\n" +
		                "    fill-color: #4169e1;\n" +
		                "    text-mode: normal; \n" +
		                "}" + "node#0 {\r\n" + 
		        		"	fill-color: #08a045;\r\n" + "}" + "node:clicked {\r\n" + "	fill-color: red;\r\n" + "}"
		                + "graph {\r\n"
		        		+ "	fill-color: lightgray;\r\n"
		        		+ "}");
				
				
				
				for (Entry<Integer, DTNode> entry : T2.V.entrySet()) {
					DTNode node = entry.getValue();
					graph_T2.addNode(entry.getKey().toString()).setAttribute("ui.label", node.name);
				}
				
				int edge_counter1 = 0;
				for (Entry<Pair<Integer, Integer>, Character> entry : T2.E.entrySet()) {
					Pair<Integer, Integer> edge = entry.getKey();
					
					String node_v = edge.getValue0().toString();
					String node_u = edge.getValue1().toString();
					String edge_label = entry.getValue().toString();
					
					graph_T2.addEdge(edge_label + "(" + edge_counter1 + ")", node_v, node_u, true).setAttribute("ui.label", edge_label);
					edge_counter1++;
				}
				// ==============================================================================================================
				
				HierarchicalLayout h1 = new HierarchicalLayout();
				graph_T1.display(false).enableAutoLayout(h1);
				
				HierarchicalLayout h2 = new HierarchicalLayout();
				graph_T2.display(false).enableAutoLayout(h2);
	}
	
	public static void main(String[] args) throws OWLOntologyCreationException {
		
		Pair<DescriptionTree, DescriptionTree> DTs = Eq_1();
		
		DescriptionTree T1 = DTs.getValue0();
		DescriptionTree T2 = DTs.getValue1();
		
		displayTrees(T1, T2);
		
//		Functions.displayTree(T1, T2);
//		System.out.println("T1.E = " + T1.E);
//		System.out.println("T2.E = " + T2.E);
//		System.out.println("T1.tree = " + T1.tree);
//		System.out.println("T2.tree = " + T2.tree);
		
		
		
		XeNON xenon = new XeNON(T1, T2);
		
//		Map i = xenon.subtreeIsomorphisms();
		Map i = xenon.heuristicsSubtreeIsomorphisms();
		
		Set<Set<String>> H = xenon.constructHypotheses(i, "SubClassOf");
		
		System.out.println("H = ");
		for (Set<String> element : H) {
			for (String el : element) {
				System.out.println("\t" + el);
			}
			System.out.println("----------");
		}
		
		System.out.println("---");
		
		// ==============================================================================================================
		
//		Set<Integer> s1 = new HashSet<Integer>();
//		Set<Integer> s2 = new HashSet<Integer>();
//		s1.add(1);
//		s1.add(3);
//		s1.add(4);
//		
//		s2.add(1);
//		s2.add(3);
//		
//		Pair<Set<Integer>, Set<Integer>> r = new Pair<Set<Integer>, Set<Integer>>(s1, s2);
//		List<List<Pair<Integer, Integer>>> mappings = xenon.mapEquivalenceClasses(r);
//		
//		System.out.println("Mappings for r = " + r);
//		System.out.println("# mappings = " + mappings.size());
////		Functions.printSet(mappings);
//		Functions.printList(mappings);
		System.out.println("---");
	}

}
