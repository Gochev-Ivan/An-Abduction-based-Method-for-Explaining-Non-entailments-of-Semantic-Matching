package com.xai.methods;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.coode.owlapi.manchesterowlsyntax.ManchesterOWLSyntaxEditorParser;
import org.javatuples.Pair;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.model.EntityType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDeclarationAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.util.BidirectionalShortFormProvider;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;

import OWLUtils.owlUtils;

public class TestClass {
	
	public static DescriptionTree expr2tree(String C, char inputted_vertex_notation) {
		DescriptionTree T = new DescriptionTree(inputted_vertex_notation);
		
		Queue<Pair<String, Integer>> queue = new PriorityQueue<Pair<String, Integer>>();
		
		int index_v = 0;
		int index_u = 1;
		
		queue.add(new Pair<String, Integer>(C, index_v));
		
		while (!queue.isEmpty()) {
			Pair<String, Integer> pair = queue.poll();
			
			String current_C = pair.getValue0();
			
			int idx_v = pair.getValue1();
			
			List<String> result = getConjuncts(current_C);
			
			List<List<String>> expressionParts = getExpressionParts(result);
			
			System.out.println("current_C = " + current_C);
			System.out.println("result = " + result);
			System.out.println("expressionParts = " + expressionParts);
			
			for (List<String> part : expressionParts) {
				System.out.println(part);
				
				String edge_label = "";
				String concepts_labels = "";
				
				
				if (part.size() == 1) {
					
					String[] arr = part.get(0).split(" some ");
					
					edge_label = arr[0];
					concepts_labels = arr[1];
				} else {
					for (int x = 0 ; x < part.get(0).length() ; x++) { if (part.get(0).charAt(x) == ' ') { break; } edge_label += part.get(0).charAt(x); }
					
					for (int x = 0 ; x < part.get(1).length() ; x++) {
						if (part.get(1).charAt(x) == '(') { break; }
						
						concepts_labels += part.get(1).charAt(x);
					}
				}
				
				String[] arr = concepts_labels.split(" and ");
				
				
				LinkedList<String> label_v = getTopLevelConjuncts(current_C);
				LinkedList<String> label_u = new LinkedList<String>();
				
				for (int x = 0 ; x < arr.length ; x++) {
					label_u.add(arr[x]);
				}
				
				char edge_label_char = Character.MIN_VALUE;
				
				if (edge_label.length() == 1) {
					edge_label_char = edge_label.charAt(0);
				}
				
				System.out.println(edge_label_char + " / " + label_v  + " / " + label_u  + " / " + idx_v  + " / " + index_u);
				T.addEdge(idx_v, index_u, edge_label_char, label_v, label_u);
				
				if (part.size() != 1) {
					if (!part.get(1).isEmpty()) {
						queue.add(new Pair<String, Integer>(part.get(1), index_u));
					}
				}
				
				index_u++;

				for (Pair<String, Integer> el : queue) {
					System.out.println("el = " + el);
				}
				System.out.println("===");
				
			}
		}
		
		return T;
	}
	
	public static LinkedList<String> getTopLevelConjuncts(String C) {
		
		if (C.charAt(0) == '(') {
			LinkedList<String> label_v = new LinkedList<String>();
			label_v.add("T");
			return label_v;
		}
		
		LinkedList<String> label_v = new LinkedList<String>();
		
		String current_concept_label = "";
		
		for (int x = 0 ; x < C.length() ; x++) {
			if (C.charAt(x) == '(') { break; }
			
			current_concept_label += C.charAt(x);
		}
		
		String[] arr_currentConcept = current_concept_label.split(" and ");
		
		for (int x = 0 ; x < arr_currentConcept.length ; x++) {
			if (!arr_currentConcept[x].equals(" ") || !arr_currentConcept[x].equals("") || !arr_currentConcept[x].equals(null)) {
				label_v.add(arr_currentConcept[x].replaceAll(" ", ""));
			}	
		}
		
		return label_v;
	}
	
	public static List<String> getConjuncts(String C) {
		int x = 0;
		int p = 0;
		int start_idx = 0;
		int end_idx = 0;
//		int p1_idx = 0;
//		int p2_idx = 0;
		List<String> result = new LinkedList<String>();
		while (x < C.length()) {
			
			if (C.charAt(x) == '(' && p == 0) { start_idx = x; }
			
//			if (C.charAt(x) == '(' && p == 1) { p1_idx = x; }
//			
//			if (C.charAt(x) == ')' && p == 1) { p2_idx = x; }
			
			if (C.charAt(x) == '(') { p++; }
			
			if (C.charAt(x) == ')') { p--; }
			
			if (C.charAt(x) == ')' && p == 0) { 
				end_idx = x; 
				
//				System.out.println(start_idx + " / " + (p1_idx - 2) + " / " + (p1_idx + 2) + " / " + p2_idx);
				
				result.add(C.substring(start_idx + 1, end_idx)); }
			
			x++;
		}
		
		return result;
	}
	
	public static List<List<String>> getExpressionParts(List<String> result) {
		List<List<String>> expressionConj = new LinkedList<List<String>>();
		
		for (String expr : result) {
			
			List<String> temp = new LinkedList<String>();
			
			if (!expr.contains("(")) {
				temp.add(expr);
				expressionConj.add(temp);
				continue;
			}
			
			for (int x = 0 ; x < expr.length() ; x++) {
				
				char character = expr.charAt(x);
				
				if (character == '(') {
					temp.add(expr.substring(0, x - 1));
					temp.add(expr.substring(x + 1, expr.length() - 1));
					break;
				}
			}
			expressionConj.add(temp);
		}
		
//		System.out.println("expressionConj = " +  expressionConj);
		return expressionConj;
	}
	
	public static OWLAxiom parseClassExpression(OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory dataFactory, String classExpressionString) {
        
        @SuppressWarnings("deprecation")
		ManchesterOWLSyntaxEditorParser parser = new ManchesterOWLSyntaxEditorParser(dataFactory, classExpressionString);
        parser.setDefaultOntology(ontology);
        
        Set<OWLOntology> importsClosure = ontology.getImportsClosure();
        
        ShortFormProvider shortFormProvider = new SimpleShortFormProvider();
        BidirectionalShortFormProvider bidiShortFormProvider = new BidirectionalShortFormProviderAdapter(manager, importsClosure, shortFormProvider);
		OWLEntityChecker entityChecker = new ShortFormEntityChecker(bidiShortFormProvider);
		
        parser.setOWLEntityChecker(entityChecker);
        
        return parser.parseAxiom();
    }
	
	public static Pair<List<String>, List<String>> getSignatureFromExpr(String input, OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory dataFactory) {
		String[] arrayOfString = input.split(" ");
		for (int x = 0 ; x < arrayOfString.length ; x++) { arrayOfString[x] = arrayOfString[x].replaceAll("\\(", "").replaceAll("\\)", ""); }
		
        List<String> classWords = new LinkedList<String>();
        List<String> propertyWords = new LinkedList<String>();
        
		for (int x = 0 ; x < arrayOfString.length ; x++) {
			if (!arrayOfString[x].equals("and") && !arrayOfString[x].equals("some") && !arrayOfString[x].equals("SubClassOf")) {
				if (x + 1 < arrayOfString.length) {
					if (arrayOfString[x + 1].equals("some")) {
						if (!propertyWords.contains(arrayOfString[x])) {
							propertyWords.add(arrayOfString[x]);
						}
					} else {
						if (!classWords.contains(arrayOfString[x])) {
							classWords.add(arrayOfString[x]);							
						}
						
					}
				} else {
					if (!classWords.contains(arrayOfString[x])) {
						classWords.add(arrayOfString[x]);
					}
					
				}
				
			}
        	
        }
		Pair<List<String>, List<String>> Signature = new Pair<List<String>, List<String>>(classWords, propertyWords);
		
//		List<String> visitedDeclaredClassNames = new LinkedList<String>();
//		for (String className : Signature.getValue0()) {
//			if (!visitedDeclaredClassNames.contains(className)) {
//				OWLClass A = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create(className));
//				OWLDeclarationAxiom declareA = dataFactory.getOWLDeclarationAxiom(A);
//				manager.addAxiom(ontology, declareA);
//				visitedDeclaredClassNames.add(className);
//			}
//		}
//		
//		List<String> visitedDeclaredPropertyNames = new LinkedList<String>();
//		for (String propertyName : Signature.getValue1()) {
//			if (!visitedDeclaredPropertyNames.contains(propertyName)) {
//				OWLObjectProperty property = dataFactory.getOWLEntity(EntityType.OBJECT_PROPERTY, IRI.create(propertyName));
//				OWLDeclarationAxiom declareProperty = dataFactory.getOWLDeclarationAxiom(property);
//				manager.addAxiom(ontology, declareProperty);
//				visitedDeclaredPropertyNames.add(propertyName);
//			}
//		}
		
		return Signature;
	}
	
	public static void main(String[] args) throws OWLOntologyCreationException {
		
		// Parameters for simulations:
		int a = 11;
		int b = 21;
		int c = 1;
		int d = 10;
		
		String role_names = "abcdefghijklmnopqrstuvwxyz12345";
		
		String expr = "A0";
		
		int random_number_of_concepts = a + (int)(Math.random() * ((b - a) + 1));
		
		String conjunct = "";
		
		int cnt_iterations = 0;
		
		while (cnt_iterations < random_number_of_concepts) {
			
			cnt_iterations++;
			
			double pick = Math.random();
			
			if (pick >= 0.5) {
				
				int random_role_idx = 0 + (int)(Math.random() * ((role_names.length() - 1 - 0) + 1));
				
				char random_role = role_names.charAt(random_role_idx);
				
				conjunct += " and (" + random_role + " some (A" + cnt_iterations;
				
				
				
			} else {
				
				// count how many '(' and close them:
				int brackets = 0;
				for (int x = 0 ; x < conjunct.length() ; x++) { if (conjunct.charAt(x) == '(') { brackets++; } }
				
				for (int x = 0 ; x < brackets ; x++) {
					conjunct += ')';
				}
				
//				System.out.println("HERE " + conjunct);
				
				expr += conjunct;
				
				conjunct = "";
				
			}
			
			
			
			
//			System.out.println("===");
//			System.out.println("expr = " + expr);
//			System.out.println("===");
		}
		
		
//		// ============================================================================================================================================
//		/* =============================================== Translating EL concepts to Description trees =============================================== */
//		
//		// Create manager for ontology:
//		OWLOntologyManager manager = owlUtils.manager;
////		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
//			
//		// Get the data factory:
//		OWLDataFactory dataFactory = owlUtils.createDataFactory();
////		
////		// Create IRI of ontology:
//		int i = 11;
//		IRI ontologyIRI = IRI.create("http://create-hypothesis" + i + "#");
////		
////		// Create an empty ontology:
//		OWLOntology ontology = manager.createOntology(ontologyIRI);
////		
////		// Input concept expression:
//		String input = "A0 and (r some (A1 and (s some A2) and (p some A3))) SubClassOf T";
//		
//		
//		
//		String[] arrayOfString = input.split(" ");
//		for (int x = 0 ; x < arrayOfString.length ; x++) { arrayOfString[x] = arrayOfString[x].replaceAll("\\(", "").replaceAll("\\)", ""); }
//		
//        List<String> classWords = new LinkedList<String>();
//        List<String> propertyWords = new LinkedList<String>();
//        
//		for (int x = 0 ; x < arrayOfString.length ; x++) {
//			if (!arrayOfString[x].equals("and") && !arrayOfString[x].equals("some") && !arrayOfString[x].equals("SubClassOf")) {
//				if (x + 1 < arrayOfString.length) {
//					if (arrayOfString[x + 1].equals("some")) {
//						if (!propertyWords.contains(arrayOfString[x])) {
//							propertyWords.add(arrayOfString[x]);
//						}
//					} else {
//						if (!classWords.contains(arrayOfString[x])) {
//							classWords.add(arrayOfString[x]);							
//						}
//						
//					}
//				} else {
//					if (!classWords.contains(arrayOfString[x])) {
//						classWords.add(arrayOfString[x]);
//					}
//					
//				}
//				
//			}
//        	
//        }
//		Pair<List<String>, List<String>> Signature = new Pair<List<String>, List<String>>(classWords, propertyWords);
//		
//		List<String> visitedDeclaredClassNames = new LinkedList<String>();
//		for (String className : Signature.getValue0()) {
//			if (!visitedDeclaredClassNames.contains(className)) {
//				OWLClass A = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create(className));
//				OWLDeclarationAxiom declareA = dataFactory.getOWLDeclarationAxiom(A);
//				manager.addAxiom(ontology, declareA);
//				visitedDeclaredClassNames.add(className);
//			}
//		}
//		
//		List<String> visitedDeclaredPropertyNames = new LinkedList<String>();
//		for (String propertyName : Signature.getValue1()) {
//			if (!visitedDeclaredPropertyNames.contains(propertyName)) {
//				OWLObjectProperty property = dataFactory.getOWLEntity(EntityType.OBJECT_PROPERTY, IRI.create(propertyName));
//				OWLDeclarationAxiom declareProperty = dataFactory.getOWLDeclarationAxiom(property);
//				manager.addAxiom(ontology, declareProperty);
//				visitedDeclaredPropertyNames.add(propertyName);
//			}
//		}
//		
//		// Construct OWLAxiom:
//		OWLAxiom exp = owlUtils.parseClassExpression(ontology, manager, dataFactory, input);
//		
//		
//		
//		// ============================================================================================================================================
//		// ============================================================================================================================================
//		// W.I.P.:
//		// Input concept expression:
//		
//		
//		
//		// ============================================================================================================================================
//		String C = "A1 and A2 and A3 (r some (A1 and (s some (A2 and (r some A4))) and (p some A3))) and (p some (A5 and A6 and (s some A7))) and (r some A8)";
//		
//		DescriptionTree T = expr2tree(C, 'w');
//		
//		T.displayTree();
//		
//		boolean[] flag = new boolean[T.V.size()];
//	    Arrays.fill(flag, true);
//		T.printNTree(0, flag, 0, false);
//		// ============================================================================================================================================
//		
//		
//		Pair<List<String>, List<String>> Sigma = getSignatureFromExpr(C, ontology, manager, dataFactory);
//		
//		List<String> Nc = Sigma.getValue0();
//		List<String> Nr = Sigma.getValue1();
//		
////		System.out.println("C = " + C);
////		System.out.println("Nc = " + Nc);
////		System.out.println("Nr = " + Nr);
//		
//		Stack<String> stack = new Stack<String>();
//		
//		String[] arr_exp = C.split(" ");
//		
//		List<String> conj = new LinkedList<String>();
//		
//		conj.add("(");
//		
//		// Function for separating the input string of the axiom:
//		for (int x1 = 0 ; x1 < arr_exp.length ; x1++) {
//			
//			if (!arr_exp[x1].contains("(") && !arr_exp[x1].contains(")")) {
//				conj.add(arr_exp[x1]);
//			}
//			
//			else if (arr_exp[x1].contains("(") && arr_exp[x1].contains(")")) {
//				int cnt = 0;
//				for (int y1 = 0 ; y1 < arr_exp[x1].length() ; y1++) { if (arr_exp[x1].charAt(y1) == '(') { cnt++; } }
//				
//				for (int y1 = 0 ; y1 < cnt ; y1++) { conj.add("("); }
//				
//				conj.add(arr_exp[x1].replaceAll("\\(", "").replaceAll("\\)", ""));
//				
//				int cnt1 = 0;
//				for (int y1 = 0 ; y1 < arr_exp[x1].length() ; y1++) { if (arr_exp[x1].charAt(y1) == ')') { cnt1++; } }
//				
//				for (int y1 = 0 ; y1 < cnt1 ; y1++) { conj.add(")"); }
//			}
//			else if (arr_exp[x1].contains("(") && !arr_exp[x1].contains(")")) {
//				int cnt = 0;
//				for (int y1 = 0 ; y1 < arr_exp[x1].length() ; y1++) { if (arr_exp[x1].charAt(y1) == '(') { cnt++; } }
//				
//				for (int y1 = 0 ; y1 < cnt ; y1++) { conj.add("("); }
//				
//				conj.add(arr_exp[x1].replaceAll("\\(", "").replaceAll("\\)", ""));
//			}
//			
//			else if (!arr_exp[x1].contains("(") && arr_exp[x1].contains(")")) {
//				conj.add(arr_exp[x1].replaceAll("\\(", "").replaceAll("\\)", ""));
//				
//				int cnt = 0;
//				for (int y1 = 0 ; y1 < arr_exp[x1].length() ; y1++) { if (arr_exp[x1].charAt(y1) == ')') { cnt++; } }
//				
//				for (int y1 = 0 ; y1 < cnt ; y1++) { conj.add(")"); }
//			}	
//		}
//		
//		conj.add(")");
//		
//		DescriptionTree T1 = new DescriptionTree('v');
//		
////		LinkedList<String> label_v1 = new LinkedList<String>();
////		label_v1.add("A");
////		LinkedList<String> label_u1 = new LinkedList<String>();
////		label_u1.add("D");
////		T1.addEdge(0, 1, 'r', label_v1, label_u1);
//		
//		LinkedList<List<String>> Labels_V = new LinkedList<List<String>>(); 
//		
//		int depth = 0;
//		for (int x1 = 0 ; x1 < conj.size() ; x1++) {
//			
////			System.out.println("conj.get(" + x1 + ") = " + conj.get(x1));
//			
//			if (x1 == 0) { Labels_V.add(new LinkedList<String>()); }
//			
//			if (conj.get(x1).equals("and")) { continue; }
//			
//			if (conj.get(x1).equals("(") && conj.get(x1 + 2).equals("some")) {
//				Labels_V.add(new LinkedList<String>());
//				
//				depth++;
//			}
//			
//			if (!conj.get(x1).equals("(") && !conj.get(x1).equals(")") && !conj.get(x1).equals("and") && !conj.get(x1).equals("some") && !conj.get(x1 + 1).equals("some")) {
//				
////				System.out.println(depth + conj.get(x1));
//				
//				Labels_V.get(depth).add(conj.get(x1));
//			}
//			
////			if (conj.get(x).equals(")")) { depth--; }
//			
////			else Labels_V.get(depth).add(conj.get(x));
//			
////			if (conj.get(x).equals("and") || conj.get(x).equals("some")) { continue; }
////			else if (conj.get(x).equals("(") || (conj.get(x).equals("some") && !conj.get(x + 1).equals("("))) { depth++; Labels_V.add(new LinkedList<String>()); }
////			
////			else if (conj.get(x).equals(")")) { depth--; continue; }
////			
////			else {
////				Labels_V.get(depth).add(conj.get(x));
////				
////				depth ++;
////			}
//			
//			
//		}
//		
////		System.out.println("conj = " + conj);
////		System.out.println("Labels_V = " + Labels_V);
////		System.out.println("depth = " + depth);
////		System.out.println("====================================================================================================");
////		System.out.println("C = " + C);
//		
//		Stack<String> parenthesisStack = new Stack<String>();
//		List<String> conjuncts = new LinkedList<String>();
//		
//		Matcher m = Pattern.compile("\\((.*?)\\)").matcher(C);
//		while (m.find()) {
//			conjuncts.add(m.group(1));
//		}
//		
////		System.out.println("conjuncts = " + conjuncts);
//		
//		// A0 and (r some (A1 and (s some (A2 and (r some A4)))) and (p some A3)
//		
//		
//		// ============================================================================================================================================
//		// ============================================================================================================================================
//		
//		// ============================================================================================================================================
////		OWLOntology ontology = owlUtils.loadOntology("C:\\Users\\Desktop\\test_expl_1.owl");
//		// ============================================================================================================================================
//		
//		
//		// ============================================================================================================================================
////		// Create manager for ontology:
////		OWLOntologyManager manager = owlUtils.manager;
////		
////		// Get the data factory:
////		OWLDataFactory dataFactory = owlUtils.createDataFactory();
////		
////		// Create IRI of ontology:
////		int i = 1;
////		IRI ontologyIRI = IRI.create("http://create-hypothesis" + i + "#");
////		
////		// Create an empty ontology:
////		OWLOntology ontology = manager.createOntology(ontologyIRI);
////		
////		// Add the class and property names:
////		OWLClass A = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Animal"));
////		OWLClass B = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Cat"));
////		OWLClass C = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Dog"));
//////		OWLClass D = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Mouse"));
//////		OWLObjectProperty property = dataFactory.getOWLEntity(EntityType.OBJECT_PROPERTY, IRI.create("meows"));
////		
////		// Create declaration axioms:
////		OWLDeclarationAxiom declareA = dataFactory.getOWLDeclarationAxiom(A);
////		OWLDeclarationAxiom declareB = dataFactory.getOWLDeclarationAxiom(B);
////		OWLDeclarationAxiom declareC = dataFactory.getOWLDeclarationAxiom(C);
//////		OWLDeclarationAxiom declareD = dataFactory.getOWLDeclarationAxiom(D);
//////		OWLDeclarationAxiom declareProperty = dataFactory.getOWLDeclarationAxiom(property);
////		
////		// Add the axioms to the ontology via the manager:
////		manager.addAxiom(ontology, declareA);
////		manager.addAxiom(ontology, declareB);
////		manager.addAxiom(ontology, declareC);
//////		manager.addAxiom(ontology, declareD);
//////		manager.addAxiom(ontology, declareProperty);
////	    
////		// Read the input:
////        String input = "Cat or Dog SubClassOf Animal";  // TODO: Identify which are class names and which are property names and then declare them.
//////		String input2 = "Cat SubClassOf Animal";
//////        String input3 = "PersianCat SubClassOf Cat";
////        
////        String[] arrayOfString = input.split(" ");
////        
////        List<String> classWords = new LinkedList<String>();
////        List<String> propertyWords = new LinkedList<String>();
////        
////		for (int x = 0 ; x < arrayOfString.length ; x++) {
////			if (!arrayOfString[x].equals("and") && !arrayOfString[x].equals("some") && !arrayOfString[x].equals("SubClassOf") && !arrayOfString[x].equals("or")) {
////				if (x + 1 < arrayOfString.length) {
////					if (arrayOfString[x + 1].equals("some")) {
////						if (!propertyWords.contains(arrayOfString[x])) {
////							propertyWords.add(arrayOfString[x]);
////						}
////					} else {
////						if (!classWords.contains(arrayOfString[x])) {
////							classWords.add(arrayOfString[x]);							
////						}
////						
////					}
////				} else {
////					if (!classWords.contains(arrayOfString[x])) {
////						classWords.add(arrayOfString[x]);
////					}
////					
////				}
////				
////			}
////        	System.out.println(arrayOfString[x]);
////        }
////        
////		System.out.println("class words = " + classWords);
////		System.out.println("property words = " + propertyWords);
////        
//////        OWLClass cat = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Cat"));
//////        OWLClass mouse = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Mouse"));
//////        OWLClass dog = dataFactory.getOWLEntity(EntityType.CLASS, IRI.create("Dog"));
////        
//////        OWLObjectProperty meows = dataFactory.getOWLEntity(EntityType.OBJECT_PROPERTY, IRI.create("meows"));
//////        OWLObjectProperty barks = dataFactory.getOWLEntity(EntityType.OBJECT_PROPERTY, IRI.create("barks"));
////        
//////        OWLDeclarationAxiom declareCat = dataFactory.getOWLDeclarationAxiom(cat);
//////		OWLDeclarationAxiom declareMouse = dataFactory.getOWLDeclarationAxiom(mouse);
//////		OWLDeclarationAxiom declareDog = dataFactory.getOWLDeclarationAxiom(dog);
//////		OWLDeclarationAxiom declareMeows = dataFactory.getOWLDeclarationAxiom(meows);
//////		OWLDeclarationAxiom declareBarks = dataFactory.getOWLDeclarationAxiom(barks);
////        
//////		manager.addAxiom(ontology, declareCat);
//////		manager.addAxiom(ontology, declareMouse);
//////		manager.addAxiom(ontology, declareDog);
//////		manager.addAxiom(ontology, declareMeows);
//////		manager.addAxiom(ontology, declareBarks);
////		
////        try {
////			OWLAxiom exp = parseClassExpression(ontology, manager, dataFactory, input);
//////			OWLAxiom exp2 = parseClassExpression(ontology, manager, dataFactory, input2);
//////			OWLAxiom exp3 = parseClassExpression(ontology, manager, dataFactory, input3);
////					
////			// Output (prints):
////			System.out.println(exp);
//////			System.out.println(exp2);
//////			System.out.println(exp3);
////			
////			manager.addAxiom(ontology, exp);
//////			manager.addAxiom(ontology, exp2);
//////			manager.addAxiom(ontology, exp3);
////			
////		} catch (Exception e) {
////			e.printStackTrace();
////		}
////        
////        // Save the ontology:
////        try {
////        	
////        	String new_path = "C:\\Users\\Ivan\\Desktop\\saved-onto.owl";
////        	
////        	OWLReasoner reasoner = owlUtils.getReasoner(ontology);
////        	
////        	owlUtils.SyncReasoner(reasoner);
////         	
////        	System.out.println("---");
////        	
////        	System.out.println("# of axioms " + ontology.getAxioms().size());
////        	Functions.printAxioms(ontology.getAxioms());
////        	
////        	System.out.println("---");
////        	
////			manager.saveOntology(ontology, new FunctionalSyntaxDocumentFormat(), IRI.create((new File(new_path).toURI())));
////		} catch (OWLOntologyStorageException e) {
////			e.printStackTrace();
////		}
//		// ============================================================================================================================================
		
	}
}
