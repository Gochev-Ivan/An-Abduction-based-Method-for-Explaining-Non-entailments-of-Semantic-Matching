package com.xai.methods;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.javatuples.Pair;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;

import Trees.DTNode;

public class TestClass_2 {
	
	/**
	 * Function that returns the explanations for a non-entailment.
	 * 
	 * @param vertex_notation
	 * @return T
	 * 
	 * @throws OWLOntologyCreationException 
	 */
	public static DescriptionTree generateRandomDescriptionTree(char vertex_notation, int a, int b, int c, int d) {
		
		// TODO: This function is not complete. int randomNum = min + (int)(Math.random() * ((max - min) + 1));
		
		DescriptionTree T = new DescriptionTree(vertex_notation);
		
		// starting point of num_random_parts
		int e = 1;
		
	    // Define role names - currently there are 21 role names:
//		String role_names = "rspqabcdefghijklmnotz";
		String role_names = "abcdefghijklmnopqrstuvwxyz12345";
		
		// Get random number of vertices:
		int num_vertices_T = a + (int)(Math.random() * ((b - a) + 1));
		
		// Generate random vertex sets with labels:
		Map<Integer, LinkedList<String>> V = new HashMap<Integer, LinkedList<String>>();
		
		for (int x = 0 ; x < num_vertices_T ; x++) {
			LinkedList<String> label_v = new LinkedList<String>();
			
			label_v.add("A" + x);
			
			V.put(x, label_v);
		}
		
		// Generate random edge sets with labels:
		int num_labels_T = c + (int)(Math.random() * ((d - c) + 1));
		
		List<Character> E_labels = new LinkedList<Character>(); 
		for (int idx = 0 ; idx < num_labels_T ; idx++) {
			E_labels.add(role_names.charAt(idx));
		}
		
		Map<Pair<Integer, Integer>, Character> E = new HashMap<Pair<Integer, Integer>, Character>();
		
		List<Integer> num_random_parts = new LinkedList<Integer>();
		
		int x = V.size() - e;
		
		if (x == 0) {
			num_random_parts.add(0);
		}
		else {
			
			int randomNum = 1 + (int)(Math.random() * ((x - 1) + 1));
			
			num_random_parts.add(randomNum);
			
			x = Math.abs(x - num_random_parts.get(num_random_parts.size() - 1));
			
			while (x != 0) {
				
				int sum_random_parts = 0;
				for (Integer el : num_random_parts) {
					sum_random_parts += el;
				}
				
				int y = 1 + (int)(Math.random() * (((V.size() - sum_random_parts - 1) - 1) + 1));
				
				num_random_parts.add(y);
				
				x = Math.abs(x - y);
				
				if (x == 0) { break; }
			}
		}
		
		for (int i = 0 ; i < num_random_parts.size() ; i++) {
			
			int sum_num_random_parts_i = 0;
			for (int k = 0 ; k < num_random_parts.size() ; k++) {
				
				if (k == i) { break; }
				sum_num_random_parts_i += num_random_parts.get(k);
				
				
			}
			sum_num_random_parts_i++;
			
			int sum_num_random_parts_i1 = 0;
			for (int k = 0 ; k < num_random_parts.size() ; k++) {
				
				if (k == i + 1) { break; }
				
				sum_num_random_parts_i1 += num_random_parts.get(k);
				
				
			}
			sum_num_random_parts_i1++;
			
			for (int j = sum_num_random_parts_i ; j < sum_num_random_parts_i1 ; j++) {
				if (i != j) {
					
					int random_index = 0 + (int)(Math.random() * (((E_labels.size() - 1) - 0) + 1));
					
					E.put(new Pair<Integer, Integer>(i, j), E_labels.get(random_index));
				}
			}
		}
		
		for ( Entry<Pair<Integer, Integer>, Character> entry : E.entrySet()) {
			Pair<Integer, Integer> edge = entry.getKey();
			Character role = entry.getValue();
			
			LinkedList<String> Lv = V.get(edge.getValue0());
			LinkedList<String> Lu = V.get(edge.getValue1());
			
			T.addEdge(edge.getValue0(), edge.getValue1(), role, Lv, Lu);
		}
		
		return T;
	}
	
	public static void main(String[] args) {
		
		// Parameters for simulations:
		int a = 2;
		int b = 10;
		int c = 1;
		int d = 10;
				
		DescriptionTree T = generateRandomDescriptionTree('v', a, b, c, d);
		System.out.println(T.tree);
		System.out.println(T.E);
		
		int root = 0;
		
		String expr = "";
		
		LinkedList<LinkedList<Integer>> paths = T.DFSCompletePaths(root);
		
		System.out.println("paths = " + paths);
		
		for (LinkedList<Integer> path : paths) {
			
			String conjunct = "";
			
			
			for (int i = 0 ; i < path.size() - 1 ; i++) {
				
				int node1_idx = path.get(i);
				int node2_idx = path.get(i + 1);
				
				DTNode node1 = T.V.get(node1_idx);
				DTNode node2 = T.V.get(node2_idx);
				
				conjunct += String.join(" and ", node1.label) + " and (" + T.E.get(new Pair<Integer, Integer>(node1_idx, node2_idx)) + " some (";
				
			}
			
			conjunct += String.join(" and ", T.V.get(path.get(path.size() - 1)).label);
			
			int cnt = 0;
			for (int x = 0 ; x < conjunct.length() ; x++) { if (conjunct.charAt(x) == '(') { cnt++; } }
			
			for (int x = 0 ; x < cnt ; x++) {
				conjunct += ')';
			}
			
			conjunct += " and ";
			
			expr += conjunct;
			
		}
		
		expr = expr.substring(0, expr.length() - 5);
	
		System.out.println("expr = " + expr);
		
	}
}
