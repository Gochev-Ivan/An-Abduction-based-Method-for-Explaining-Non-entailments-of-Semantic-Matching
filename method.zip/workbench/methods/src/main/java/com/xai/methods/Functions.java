package com.xai.methods;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.IntStream;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

import org.javatuples.Pair;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;

import OWLUtils.owlUtils;
import Trees.DTNode;

public class Functions {
	
	/**
	 * Function that prints a map.
	 * 
	 * @param <K>
	 * @param <V>
	 * @param m
	 */
	public static <K, V> void printMap(Map<K, V> m) {
		for ( Entry<K, V> entry : m.entrySet() ) {
		    System.out.println(entry.getKey().toString()
		    		.replaceAll(owlUtils.prefix1, "")
		    		.replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
		    		.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
		    		.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
		    		.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", "")
		    		+ " --> " + entry.getValue());
		}
	}
	
	/**
	 * Function that prints a map.
	 * 
	 * @param <K>
	 * @param <V>
	 * @param m
	 */
	public static <K, V> void printIsomorphisms(Map<Integer, List<Pair<DTNode, DTNode>>> m) {
		for ( Entry<Integer, List<Pair<DTNode, DTNode>>> entry : m.entrySet() ) {
//			System.out.println("----------------------------------------------------------------------------------------------------");
			System.out.print(entry.getKey().toString() + " --> ");
		    for (Pair<DTNode, DTNode> currentMap : entry.getValue()) {
		    	System.out.print("(" + currentMap.getValue0().name + currentMap.getValue1().name + ")");
			}
//		    System.out.println("\n----------------------------------------------------------------------------------------------------");
		    System.out.println();
		}
	}
	
	/**
	 * Function that prints a map.
	 * 
	 * @param <K>
	 * @param <V>
	 * @param m
	 */
	public static <K, V> void printV(Map<Integer, DTNode> m) {
		for ( Entry<Integer, DTNode> entry : m.entrySet() ) {
		    System.out.println(entry.getKey().toString()
		    		.replaceAll(owlUtils.prefix1, "")
		    		.replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
		    		.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
		    		.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
		    		.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", "")
		    		+ " --> " + entry.getValue().name);
		}
	}
	
	/**
	 * Function that prints a matrix.
	 * 
	 * @param <K>
	 * @param <V>
	 * @param m
	 */
	public static <K, V> void printMatrix(int[][] m) {
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				System.out.print(m[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	/**
	 * Function that prints a matrix.
	 * 
	 * @param <K>
	 * @param <V>
	 * @param m
	 */
	public static <K, V> void printMatrix(char[][] m) {
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m.length; j++) {
				System.out.print(m[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	
	/**
	 * Function that prints a set in new lines.
	 * 
	 * @param <T>
	 * @param setToPrint
	 */
	public static <T> void printSet(Set<T> setToPrint) {
		for (T element : setToPrint) {
			System.out.println(element.toString().replaceAll(owlUtils.prefix1, "").replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
					.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
					.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
					.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", ""));
		}
	}
	
	
	/**
	 * Function that prints a list in new lines.
	 * 
	 * @param <T>
	 * @param listToPrint
	 */
	public static <T> void printList(List<T> listToPrint) {
		for (T element : listToPrint) {
			System.out.println(element.toString().replaceAll(owlUtils.prefix1, "").replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
					.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
					.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
					.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", ""));
		}
	}
	
	
	/**
	 * Function that prints a set of OWL axioms.
	 * 
	 * @param axioms
	 */
	public static void printAxioms(Set<OWLAxiom> axioms) {
		for (OWLAxiom ax : axioms) {
	    	System.out.println(ax.toString().replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
	    									.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
	    									.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
	    									.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", ""));
		}
	}
	
	
	/**
	 * Function that prints a set of OWL class expressions.
	 * 
	 * @param s
	 */
	public static void printSetOfClassExpressions(Set<OWLClassExpression> s) {
		for (OWLClassExpression ax : s) {
	    	System.out.println(ax.toString().replaceAll(owlUtils.prefix1, "").replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
	    									.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
	    									.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
	    									.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", ""));
		}
	}
	
	
	/**
	 * Function that prints a set of OWL equivalent classes axioms.
	 * 
	 * @param equivalentClasses
	 */
	public static void printSetOfEquivalentClassesAxioms(Set<OWLEquivalentClassesAxiom> equivalentClasses) {
		for (OWLAxiom ax : equivalentClasses) {
	    	System.out.println(ax.toString().replaceAll(owlUtils.prefix1, "").replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
	    									.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
	    									.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
	    									.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", ""));
		}
	}
	
	
	/**
	 * Function that returns the n-th element of a set with elements OWL equivalent classes axioms.
	 * @param <T>
	 * 
	 * @param s
	 * @param n
	 * @return
	 */
	public static <T> T getNthElementOfSet(Set<T> s, int n) {
		Iterator<T> it = s.iterator();
		int i = 0;
		
		while( it.hasNext() ) {
			T element = it.next();
	        if ( i == n ) {
	        	return element;
	        }
	        i++;
	    }
		
		return null;
	}
	
	
	/**
	 * Function that returns a String without ontology prefixes (for neat presentation).
	 * 
	 * @param concept_name_HVP
	 * @return
	 */
	public static String clearPrefixes(OWLClassExpression concept_name_HVP) {
		return concept_name_HVP.toString().replaceAll(owlUtils.prefix1, "").replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
				.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
				.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
				.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", "");
	}
	
	
	/**
	 * Function that returns a String without ontology prefixes (for neat presentation).
	 * 
	 * @param s
	 * @return
	 */
	public static String clearStringPrefixes(String s) {
		return s.replaceAll(owlUtils.prefix1, "").replaceAll("http://www.co-ode.org/ontologies/pizza/pizza.owl#", "")
				.replaceAll("http://www.w3.org/2004/02/skos/core#", "")
				.replaceAll("http://www.co-ode.org/ontologies/pizza#", "")
				.replaceAll("http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#", "");
	}
	
	
	/**
	 * Function that transfers elements from a set to a list.
	 * 
	 * @param <T>
	 * @param s
	 * @return
	 */
	public static <T> List<T> set2list(Set<T> s) {
		List<T> l = new LinkedList<T>();
		
		for (T element : s) {
			l.add(element);
		}
		
		return l;
	}
	
	/**
	 * Function that transfers elements from a list to a set.
	 * 
	 * @param <T>
	 * @param l
	 * @return
	 */
	public static <T> Set<T> list2set(List<T> l) {
		Set<T> s = new HashSet<T>();
		
		for (T element : l) {
			s.add(element);
		}
		
		return s;
	}
	
	/**
	 * Function for displaying characteristics of two description trees T1 and T2.
	 * 
	 * @param T1
	 * @param T2
	 * 
	 * @return 
	 */
	public static void displayTree(DescriptionTree T1, DescriptionTree T2) {
		LinkedList<LinkedList<Integer>> paths_T1 = T1.DFSCompletePaths(0);
	    LinkedList<LinkedList<Integer>> paths_T2 = T2.DFSCompletePaths(0);
	    
	    System.out.println("========== T1 ==========");
	    T1.displayTree();
	    System.out.println("========== T2 ==========");
	    T2.displayTree();
	    System.out.println("==========");
	    System.out.println("h(T1) = " + T1.height);
	    System.out.println("h(T2) = " + T2.height);
	    System.out.println("==========");
	    Functions.printList(paths_T1);
	    System.out.println("-------");
	    Functions.printList(paths_T2);
	    System.out.println("==========");
	}
	
	/**
	 * Function for displaying a tree in the console.
	 * 
	 * @param T
	 * 
	 * @return 
	 */
	public static void displayTree(DescriptionTree T) {
		boolean[] flag = new boolean[T.V.size()];
		for (int i = 0; i < flag.length; i++) { flag[i] = true; }
		
		T.printNTree(0, flag , 0, false);
	}
	
	public static int[][] adjacencyMatrix(Map<Integer, List<Pair<Integer, Integer>>> nodesMap, List<Pair<Integer, Integer>> edgeList) {
		// Define the adjacency matrix A:
		
		int[][] A = new int[nodesMap.keySet().size()][nodesMap.keySet().size()];
		
		// Initialize the adjacency matrix A (all values to 0):
		for (int i = 0; i < A.length; i++) { for (int j = 0; j < A.length; j++) { A[i][j] = 0; } }
		
		for (Pair<Integer, Integer> e : edgeList) { A[e.getValue0()][e.getValue1()] = 1; }
		
		return A;
	}
	
	public static List<List<Integer>> pathfinder(int[][] A) {
		Queue<Integer> indexes = new PriorityQueue<Integer>();
		List<List<Integer>> paths = new LinkedList<List<Integer>>();
		
		for (int j = 0 ; j < A.length ; j++) {
			if (A[0][j] == 1) {
				indexes.add(j);
				
				List<Integer> tempPath = new LinkedList<Integer>();
				tempPath.add(0);
				tempPath.add(j);
				
				paths.add(tempPath);
			}
		}
		
		while (!indexes.isEmpty()) {
			
			int idx = indexes.poll();
			
			if (idx >= A.length) { continue; }
			
			for (int k = 0 ; k < A[idx].length ; k++) {
				if (A[idx][k] == 1) {
					
					int i = 0;
					
					List<List<Integer>> tempPaths = new LinkedList<List<Integer>>(paths);
					
					while (i < tempPaths.size()) {
						if (idx == tempPaths.get(i).get(tempPaths.get(i).size() - 1)) {
							
							List<Integer> temp = new LinkedList<Integer>(paths.get(i));
							temp.add(k);
							paths.add(temp);
						}
						i += 1;
					}
					indexes.add(k);
				}
			}
		}
		return paths;
	}
	
	public static List<List<Integer>> setOfAllCompletePaths(int[][] A) {
			
			List<List<Integer>> paths = pathfinder(A);
			
			List<List<Integer>> completePaths = new LinkedList<List<Integer>>();
			
			for (List<Integer> path : paths) {
				int vertex = path.get(path.size() - 1);
				
				int sum = IntStream.of(A[vertex]).sum();
				
				if (sum == 0) { completePaths.add(path); }
			}
			
			return completePaths;
	}
	
}





















