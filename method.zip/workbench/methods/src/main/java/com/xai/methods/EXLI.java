package com.xai.methods;

public class EXLI {
	public DescriptionTree T1;
	public DescriptionTree T2;

	/**
	 * Constructor for class {@link EXLI}
	 * 
	 * @param T1
	 * @param T2
	 * 
	 * @return 
	 */
	public EXLI(DescriptionTree T1, DescriptionTree T2) {
		this.T1 = T1;
		this.T2 = T2;
	}
	
	/**
	 * Method for computing subtree isomorphisms between two description trees T1 and T2.
	 * 
	 * @param T1
	 * @param T2
	 * 
	 * @return 
	 */
	public void subtreeIsomorphisms() {
		
	}
}
