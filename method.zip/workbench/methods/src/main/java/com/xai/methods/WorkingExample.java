package com.xai.methods;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.Map.Entry;

import org.coode.owlapi.manchesterowlsyntax.ManchesterOWLSyntaxEditorParser;
import org.javatuples.Pair;
import org.javatuples.Triplet;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.model.EntityType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDeclarationAxiom;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.util.BidirectionalShortFormProvider;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;

import OWLUtils.owlFunctions;
import OWLUtils.owlUtils;
import Trees.DTNode;
import openllet.owlapi.OpenlletReasoner;
import openllet.owlapi.OpenlletReasonerFactory;

public class WorkingExample {
	
	public static Pair<DescriptionTree, DescriptionTree> workingExample() {
		DescriptionTree T1 = new DescriptionTree('v');
		
		LinkedList<String> label_v = new LinkedList<String>();
		label_v.add("Scan");
		LinkedList<String> label_u = new LinkedList<String>();
		label_u.add("X-RayC.T.");

		T1.addEdge(0, 1, 'r', label_v, label_u);
		
		LinkedList<String> label_v1 = new LinkedList<String>();
		label_v1.add("Scan");
		LinkedList<String> label_u1 = new LinkedList<String>();
		label_u1.add("X-RayTube");
		T1.addEdge(0, 2, 's', label_v1, label_u1);
		
		LinkedList<String> label_v2 = new LinkedList<String>();
		label_v2.add("Scan");
		LinkedList<String> label_u2 = new LinkedList<String>();
		label_u2.add("X-Ray");
		T1.addEdge(0, 3, 'p', label_v2, label_u2);
		
		LinkedList<String> label_v3 = new LinkedList<String>();
		label_v3.add("X-RayTube");
		LinkedList<String> label_u3 = new LinkedList<String>();
		label_u3.add("Rotation");
		T1.addEdge(2, 4, 'q', label_v3, label_u3);
		
		DescriptionTree T2 = new DescriptionTree('w');
		
		LinkedList<String> label_w = new LinkedList<String>();
		label_w.add("Scan");
		LinkedList<String> label_q = new LinkedList<String>();
		label_q.add("Imaging");

		T2.addEdge(0, 1, 'r', label_w, label_q);
		
		LinkedList<String> label_w1 = new LinkedList<String>();
		label_w1.add("Scan");
		LinkedList<String> label_q1 = new LinkedList<String>();
		label_q1.add("Part");
		T2.addEdge(0, 2, 's', label_w1, label_q1);
		
		LinkedList<String> label_w2 = new LinkedList<String>();
		label_w2.add("Scan");
		LinkedList<String> label_q2 = new LinkedList<String>();
		label_q2.add("IonizingRadiation");
		T2.addEdge(0, 3, 'p', label_w2, label_q2);
		
		
		Pair<DescriptionTree, DescriptionTree> DTs = new Pair<DescriptionTree, DescriptionTree>(T1, T2);
		
		return DTs;
	}
	
	public static void main(String[] args) throws OWLOntologyCreationException {
		
		Pair<DescriptionTree, DescriptionTree> DTs = workingExample();
		
		// Roles in the description trees:
		// r := performs, s := uses, p := produces, q := involves
		
		DescriptionTree T1 = DTs.getValue0();
		DescriptionTree T2 = DTs.getValue1();
		
		XeNON xenon = new XeNON(T1, T2);
		
//		Map i = xenon.subtreeIsomorphisms();
		Map i = xenon.heuristicsSubtreeIsomorphisms();
		
		Set<Set<String>> H = xenon.constructHypotheses(i, "SubClassOf");
		
		System.out.println("H = ");
		for (Set<String> element : H) {
			for (String el : element) {
				System.out.println("\t" + el);
			}
			System.out.println("----------");
		}
		
		System.out.println("---");
		
	}
}
