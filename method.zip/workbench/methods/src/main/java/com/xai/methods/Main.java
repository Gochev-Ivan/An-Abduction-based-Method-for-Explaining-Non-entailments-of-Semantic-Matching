package com.xai.methods;

import OWLUtils.*;
import Trees.Node;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Spliterator;

import org.checkerframework.common.subtyping.qual.Bottom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

@SuppressWarnings("unused")
public class Main {
	
	/**
	 * Function that assigns the probabilities to each concept w.r.t. the tree of inferred knowledge.
	 * 
	 * @param ontology
	 * @param reasoner
	 * @return
	 */
	@SuppressWarnings("unused")
	public static Map<OWLClass, Float> assignProbabilities(OWLOntology ontology, OWLReasoner reasoner) {
		Set<OWLClass> concept_names_Set = ontology.getClassesInSignature();
		
		Map<OWLClass, Float> pmf = new HashMap<OWLClass, Float>();
		
		for ( OWLClass C : concept_names_Set ) {
        	Set<OWLClass> Sub_C = owlFunctions.getAllSubClassesOfConceptViaReasoning(ontology, reasoner, C);
        	
        	// FIND THE CARDINALITIES OF Sub(C) and Nc:
            int cardinality_Sub_C = Sub_C.size();
            int cardinality_Nc = concept_names_Set.size();
            
//            System.out.println("++++++++++++++++++++++++++++++");
//            System.out.println("|Sub(" + Functions.clearPrefixes(C) + ")| = " + cardinality_Sub_C);
//            System.out.println("|Nc| = " + cardinality_Nc);
//            System.out.println("C = " + Functions.clearPrefixes(C));
//            System.out.println();
            Set<OWLClass> sup_c = owlFunctions.getDirectSuperClassesOfConceptViaReasoning(ontology, reasoner, C);
//            System.out.println("Sup(C) = ");
//            Functions.printSet(sup_c);
//            System.out.println();
//            System.out.println("++++++++++++++++++++++++++++++");
            
            // FIND THE PROBABILITY OF CONCEPT1 [P(C)]:
            float probability_C = (float) cardinality_Sub_C / (float) cardinality_Nc;
            pmf.put(C, probability_C);
        	
		}
		
		System.out.println();
		System.out.println("----------------------------------------------------------------------");
		System.out.println("//////////        //////////        //////////        //////////        //////////        //////////        //////////");
	    System.out.println("// ---------- OUTPUTS FROM PROBABILITY ASSIGNMENT: ---------- //");
//	    System.out.println();
//	    System.out.println("|Sub(C)| = " + cardinality_Sub_C);
//	    System.out.println("|O| = " + cardinality_Nc);
//	    System.out.println("=> P(C) = |Sub(C)| / |O| = " + probability_C);
//	    System.out.println();
	    System.out.println("----------------------------------------------------------------------");
	    System.out.println();
	    System.out.println("PROBABILITY MASS FUNCTION (PMF): ");
	    System.out.println();
	    Functions.printMap(pmf);
	    System.out.println();
	    System.out.println("----------------------------------------------------------------------");
		
		return pmf;
	}
	
	/**
	 * Function that neatly prints a tree structure.
	 * 
	 * @param x
	 * @param flag
	 * @param depth
	 * @param isLast
	 */
	@SuppressWarnings("rawtypes")
	public static void printNTree(Node x, boolean[] flag, int depth, boolean isLast) {
		if (x == null)
	        return;
		
		// Loop to print the depths of the
	    // current node
	    for (int i = 1; i < depth; ++i) {
	         
	        // Condition when the depth
	        // is exploring
	        if (flag[i] == true) {
	            System.out.print("| "
	               + " "
	               + " "
	               + " ");
	        }
	         
	        // Otherwise print
	        // the blank spaces
	        else {
	            System.out.print(" "
	               + " "
	               + " "
	               + " ");
	        }
	    }
	     
	    // Condition when the current
	    // node is the root node
	    if (depth == 0)
	        System.out.println(Functions.clearStringPrefixes(x.nodeName.toString()));
	     
	    // Condition when the node is
	    // the last node of
	    // the exploring depth
	    else if (isLast) {
	        System.out.print("+--- " +  Functions.clearStringPrefixes(x.nodeName.toString()) + '\n');
	         
	        // No more children turn it
	        // to the non-exploring depth
	        flag[depth] = false;
	    }
	    else {
	        System.out.print("+--- " +  Functions.clearStringPrefixes(x.nodeName.toString()) + '\n');
	    }
	 
	    int it = 0;
	    for ( Object node1 : x.children ) {
	         ++it;
	        
	        // Recursive call for the
	        // children nodes
	        printNTree((Node) node1, flag, depth + 1,
	            it == (x.children.size()) - 1);
	    }
	    flag[depth] = true;
	}
	
	
	/**
	 * Function to construct the tree of inferred knowledge in the ontology. Returns the root of the tree, through which all nodes can be accessed.
	 * 
	 * @param <T>
	 * @param ontology
	 * @param dataFactory
	 * @param reasoner
	 * @param pmf
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> Node<T> constructTree(OWLOntology ontology, OWLDataFactory dataFactory, OWLReasoner reasoner, 
																	Map<OWLClass, Float> pmf) {
		Set<OWLClass> concept_names_Set = ontology.getClassesInSignature();
		
		OWLClass top_concept = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix4, "Thing");
		concept_names_Set.remove(top_concept);
		
		Set<OWLClass> directSubClasses = owlFunctions.getDirectSubClassesOfConceptViaReasoning(ontology, reasoner, top_concept);
		
		List<OWLClass> directSubClasses_list = Functions.set2list(directSubClasses);
		
		List<Node> root_children = new ArrayList<Node>(); 
		Node<T> root = new Node(top_concept, pmf.get(top_concept), root_children);
		for ( OWLClass owlClass : directSubClasses_list ) {
			List<Node> children = new ArrayList<Node>(); 
			root.children.add(new Node(owlClass, pmf.get(owlClass), children));
		}
		
		// WHILE CONCEPT NAMES SET IS NOT EMPTY (YOU WILL REMOVE CONCEPTS AS YOU ITERATE OVER THEM)
		List<Node> currentNodeChildren = new ArrayList<Node>();
		Node<T> current_node = root;
		currentNodeChildren.addAll(current_node.children);
		while ( !currentNodeChildren.isEmpty() ) {
			
//			System.out.println("---");
//			System.out.println(current_node.nodeName);
//			for ( int i = 0 ; i < currentNodeChildren.size() ; i++ ) {
//				System.out.println(currentNodeChildren.get(i).nodeName);
//			}
//			System.out.println("---");
			
			current_node = currentNodeChildren.remove(0);
			
			OWLClass conceptName = (OWLClass) current_node.nodeName;
			
			List<OWLClass> currentNodeSubClasses = Functions.set2list(
					owlFunctions.getDirectSubClassesOfConceptViaReasoning(ontology, reasoner, conceptName));
			
			for ( OWLClass owlClass : currentNodeSubClasses ) {
				List<Node> children = new ArrayList<Node>(); 
				current_node.children.add(new Node(owlClass, pmf.get(owlClass), children));
			}
				
			currentNodeChildren.addAll(current_node.children);
		}
		
//		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		boolean[] flag = new boolean[concept_names_Set.size()];
//	    Arrays.fill(flag, true);
//		printNTree(root, flag, 0, false);
//		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		// => FIND ALL DIRECT SUBCLASSES OF THE CURRENT CONCEPT, ADD THE PMF VALUE, REMOVE IT FROM CONCEPT NAMES SET
		// => RESULT: TREE.
		
//		System.out.println("//////////        //////////        //////////        //////////        //////////        //////////        //////////");
//	    System.out.println("// ---------- OUTPUTS FROM CONSTRUCT TREE FOR ASSIGNED PROBABILITIES FUNCTION: ---------- //");
//		System.out.println(root.value);
//		System.out.println("children: ");
//		Functions.printList(root.children);
//		System.out.println("++++++++++++++++++++++++++++++");
		
		return root;
	}
	
	
	/**
	 * Function to find the probability of a concept in the tree of inferences.
	 * 
	 * @param node_name
	 * @param paths
	 * @param pmf
	 * @param Nothing
	 * @return
	 */
	public static Map<OWLClass, Float> findProbabilityOfAConcept(OWLClass node_name, List<List<OWLClass>> paths, Map<OWLClass, Float> pmf, 
			OWLClass Nothing) {
		
		Map<OWLClass, Float> probabilityOfConcept = new HashMap<OWLClass, Float>();
		
		float sum_Pn = (float) 0.0;
		
		for ( List<OWLClass> path : paths ) {
			
			if ( path.contains(node_name) ) {
				
				float p_n = (float) 1.0;
				
				for ( OWLClass concept : path ) {
					
					if ( concept.toString().compareTo(node_name.toString()) == 0 ) {
						float p_concept = pmf.get(concept);
						p_n *= p_concept;
						break;
					}
					if ( concept.toString().compareTo(Nothing.toString()) == 0 ) break;
					
					if ( pmf.get(concept) != null ) {
						float p_concept = pmf.get(concept);
						p_n *= p_concept;
					}
				}
				
				sum_Pn += p_n;
			}
		}
		
		probabilityOfConcept.put(node_name, sum_Pn);
		
		System.out.println();
//		System.out.println("======================================================================");
		System.out.println("---------- PROBABILITY OF A CONCEPT: ----------");
		Functions.printMap(probabilityOfConcept);
		
		System.out.println();
		
		System.out.println("---------- ENTROPY OF A CONCEPT: ----------");
//		System.out.println(Functions.clearPrefixes(node_name) + " --> " + (-1) * sum_Pn * (Math.log((double) sum_Pn) / Math.log(2)));
		System.out.println(Functions.clearPrefixes(node_name) + " --> " + (-1) * sum_Pn * (Math.log((double) sum_Pn)));
		
		System.out.println();
//		System.out.println("======================================================================");
		
		return probabilityOfConcept;
	}
	
	
	public static double findEntropyOfAConcept(float p_c) {
		double H_c = (float) 0.0;
		
		H_c = (-1) * p_c * (Math.log((double) p_c) / Math.log(2));
		
		System.out.println();
//		System.out.println("======================================================================");
		System.out.println("---------- ENTROPY OF A CONCEPT: ----------");
		System.out.println(H_c);
		System.out.println();
//		System.out.println("======================================================================");
		
		return H_c;
	}
	
	
	/**
	 * Function that returns a similarity measure of 2 concepts (C1 and C2) w.r.t. a hypothesis H.
	 * 
	 * @param P_C1
	 * @param P_C2
	 * @param P_H
	 * @return
	 */
	public static float similarityMeasure_1(float P_C1, float P_C2, float P_H) {
		float sim =	((float) 2.0) * ((float) Math.log(P_H)) / ((float) Math.log(P_C1) * P_C2);
		
		return sim;
	}
	
	
	/**
	 * Function for constructing the hypothesis. (UNFINISHED).
	 * 
	 * @param Sr_expr
	 * @param So_expr
	 * @param ontology
	 * @param reasoner
	 * @return
	 */
	public static Set<OWLClass> findHypothesys(OWLClassExpression Sr_expr, OWLClassExpression So_expr, OWLOntology ontology, OWLReasoner reasoner) {
		Set<OWLClass> H = new HashSet<OWLClass>();
		
		// FOR THE ABOVE DEFINED CLASS, RETURN THE SET OF ALL EquivalentTo expressions:
		Set<OWLEquivalentClassesAxiom> equivalentClasses_class1 = owlFunctions.getEquivalentClassesFromOntology(ontology, (OWLClass) So_expr);
		Set<OWLEquivalentClassesAxiom> equivalentClasses_class2 = owlFunctions.getEquivalentClassesFromOntology(ontology, (OWLClass) Sr_expr);
		
		// CHOOSE THE ONE THAT WE ARE LOOKING FOR EquivalentTo DESCRIPTION:
		OWLEquivalentClassesAxiom So = Functions.getNthElementOfSet(equivalentClasses_class1, 0);
		OWLEquivalentClassesAxiom Sr = Functions.getNthElementOfSet(equivalentClasses_class2, 0);
		
		// EXTRACT THE SETS OF ALL CONCEPTS AND ROLES FROM THE CONCEPT DESCRIPTION:
		Set<OWLClass> concepts_So = So.getClassesInSignature();
		Set<OWLObjectProperty> roles_So = So.getObjectPropertiesInSignature();
		Set<OWLClass> concepts_Sr = Sr.getClassesInSignature();
		Set<OWLObjectProperty> roles_Sr = Sr.getObjectPropertiesInSignature();
		
		
		// EXTRACT THE CLASS EXPRESSIONS FROM THE CONCEPT DESCRIPTION:
		Set<OWLClassExpression> classExpressions_So = So.getClassExpressions();
		OWLClassExpression concept_name_So = Functions.getNthElementOfSet(classExpressions_So, 0);
		OWLClassExpression concept_description_So = Functions.getNthElementOfSet(classExpressions_So, 1);
		Set<OWLClassExpression> concept_description_So_Set = Functions.getNthElementOfSet(classExpressions_So, 1).asConjunctSet();
		
		Set<OWLClassExpression> classExpressions_Sr = Sr.getClassExpressions();
		OWLClassExpression concept_name_Sr = Functions.getNthElementOfSet(classExpressions_Sr, 0);
		OWLClassExpression concept_description_Sr = Functions.getNthElementOfSet(classExpressions_Sr, 1);
		Set<OWLClassExpression> concept_description_Sr_Set = Functions.getNthElementOfSet(classExpressions_Sr, 1).asConjunctSet();
		
		// ++++++++++ ALGORITHM FOR FINDING HYPOTHESYS AND EXPLAINING SEMANTIC MATCHING: ++++++++++
		// @ToDo: 
		
		// OUTPUTS:
		System.out.println("//////////        //////////        //////////        //////////        //////////        //////////        //////////");
	    System.out.println("// ---------- OUTPUTS FROM METHOD FOR EXPLAINING SEMANTIC MATCHING: ---------- //");
	    System.out.println("----------------------------------------------------------------------");
	    System.out.println();
	    System.out.println("| CONCEPTS IN THE SEMANTIC MATCHING FORMULA: |");
	    System.out.println();
	    System.out.println("C1 := " + Functions.clearPrefixes(concept_name_So));
	    System.out.println("C2 := " + Functions.clearPrefixes(concept_name_Sr));
	    System.out.println();
	    System.out.println("----------------------------------------------------------------------");
	    System.out.println();
	    System.out.println("| CONCEPT DESCRIPTION (SET) Offer: |");
	    System.out.println();
	    Functions.printSet(concept_description_So_Set);
	    System.out.println();
	    System.out.println("----------------------------------------------------------------------");
	    System.out.println();
	    System.out.println("| CONCEPT DESCRIPTION (SET) Request: |");
	    System.out.println();
	    Functions.printSet(concept_description_Sr_Set);
	    System.out.println();
	    
		return H;
	}
	
	
	/**
	 * Function to find and return all paths to a given concept in the tree of asserted + inferred knowledge.
	 * 
	 * @param root
	 * @param nothing
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List<List<OWLClass>> findPathsToAConcept(Node<Object> root, OWLClass nothing, OWLClass node_name) {
		Queue<Node> queue = new LinkedList<Node>();
		Set<OWLClass> visited = new HashSet<OWLClass>(); 
		
		// Create a list of all paths:
		List<List<OWLClass>> paths = new ArrayList<>();
		
//		// Create a list remembering which path is closed or open (closed == 1, open == 0):
//		List<Boolean> flag = new ArrayList<>();
		
		queue.add(root);
		
		while ( !queue.isEmpty() ) {
			
//			System.out.println("//////////");
//			for (Node q : queue) {
//				System.out.print(Functions.clearPrefixes((OWLClassExpression) q.nodeName) + ", ");
//			}
//			System.out.println("//////////");
			
			// Get the next node:
			Node current_node = queue.poll();
			
			if ( !visited.contains(current_node.nodeName) ) {
			
				visited.add((OWLClass) current_node.nodeName);
				
				// Get the current node name:
				OWLClass current_node_name = (OWLClass) current_node.nodeName;
				
//				System.out.println("CURRENT NODE = " + Functions.clearPrefixes(current_node_name));
//				System.out.println("//////////");
				
				// Get the children of the next node:
				List<Node> currentNodeChildren = current_node.children;
				
				if ( paths.isEmpty() ) {
					for (Node child : currentNodeChildren) {
						List<OWLClass> newPath = new ArrayList<OWLClass>();
						newPath.add(current_node_name);
						newPath.add((OWLClass) child.nodeName);
						paths.add(newPath);
					}
					
				} else if ( !paths.isEmpty()) {
					
					List<List<OWLClass>> copy_paths = new ArrayList<>();
					
					for (List<OWLClass> list : paths) {
						copy_paths.add(list);
					}
					
					paths.removeAll(paths);
					
					for (List<OWLClass> path : copy_paths) {
						
						if ( path.contains(current_node_name) ) {
							for (Node child : currentNodeChildren) {
								List<OWLClass> newPath = new ArrayList<OWLClass>();
								newPath.addAll(path);
								newPath.add((OWLClass) child.nodeName);
								paths.add(newPath);
							}
						} else {
							paths.add(path);
						}
					}
				}
				
				List<Node> currentNodeChildren_copy = new ArrayList<Node>();
				for ( Node node : currentNodeChildren ) {
					currentNodeChildren_copy.add(node);
				}
				for ( int x = 0 ; x < currentNodeChildren_copy.size() ; x++) {
					if ( currentNodeChildren.get(x).nodeName.toString().compareTo(nothing.toString()) == 0 ) {
						currentNodeChildren.remove(x);
					}
				}
				
				queue.addAll(currentNodeChildren);
			}
		}
		
		// Output paths:
//		System.out.println("======================================================================");
		System.out.println();
		System.out.println("---------- PATHS: ----------");
		for (List<OWLClass> path : paths) {
			if ( path.contains(node_name) ) {
				for (OWLClass p : path) {
					System.out.print(Functions.clearPrefixes(p) + " => ");
				}
				System.out.println();
			}	
		}
		System.out.println();
//		System.out.println("======================================================================");
		
		return paths;
	}
	
	
	/**
	 * Function for constructing the concept description tree. (UNFINISHED)
	 * 
	 * @param <T>
	 * @param A
	 * @param ontology
	 * @param Thing
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static <T> Node<T> constructConceptDescriptionTree(OWLClass A, OWLOntology ontology, OWLClass Thing) {
		
		Set<OWLEquivalentClassesAxiom> EQ = owlFunctions.getEquivalentClassesFromOntology(ontology, A);
		
		OWLEquivalentClassesAxiom EQ_A = Functions.getNthElementOfSet(EQ, 0);
		
		Set<OWLClassExpression> C_A = EQ_A.getClassExpressions();
		OWLClassExpression Name_A = Functions.getNthElementOfSet(C_A, 0);
		OWLClassExpression Desc_A = Functions.getNthElementOfSet(C_A, 1);
		
		Set<OWLClassExpression> S_A = Functions.getNthElementOfSet(C_A, 1).asConjunctSet();
		
		
		
		Set<OWLClassExpression> S_root = new HashSet<OWLClassExpression>();
		for ( OWLClassExpression exp : S_A ) {
			if ( exp.isOWLClass() ) {
				S_root.add(exp);
			}
		}
		
		List<Node> root_children = new ArrayList<Node>();
		Node<T> root = new Node("Root", S_root, root_children);
		
		Set<OWLClassExpression> S = new HashSet<OWLClassExpression>();
		for ( OWLClassExpression exp : S_A ) {
			if ( !exp.isOWLClass() ) {
				
			}
		}
		
//		for ( OWLClass owlClass : directSubClasses_list ) {
//			List<Node> children = new ArrayList<Node>(); 
//			root.children.add(new Node(owlClass, pmf.get(owlClass), children));
//		}
		
		return root;
	}
	
	
	public static void constructConceptDescriptionGraph(OWLClass A, OWLOntology ontology) {
		
		int n = 0;  // initialize the variable for adjacency matrix size
		
		int[][] adjacency = new int[n][n];  // initialize the adjacency matrix
		
		Set<OWLClassExpression> S_A = owlFunctions.CD2Sce(ontology, A);
		
		Functions.printSet(S_A);
		
	}
	
	
	@SuppressWarnings("unused")
	public static void main(String[] args) throws OWLOntologyCreationException {
		
        //////////        //////////        //////////        //////////        //////////        //////////        //////////
		// ---------- INITIALIZATION: ---------- //
		
		// Create manager for ontology:
		OWLOntologyManager manager = owlUtils.createOntologyManager();
		
		// Load ontology from specific document:
//		String path = "C:\\Users\\goche\\Desktop\\Documents\\PhD\\Protege\\Models\\Pizza_ontology\\pizza.owl";
//		String path = "C:\\Users\\goche\\Desktop\\Documents\\PhD\\Protege\\Models\\Booking_example_v1\\B1.owl";
//		String path = "C:\\Users\\goche\\Desktop\\Documents\\PhD\\Protege\\Models\\Academic_example_v1\\A1.owl";
		String path = "C:\\Users\\Ivan\\Desktop\\Backup_08-06-2023\\Documents\\PhD\\Protege\\Models\\Academic_example_v1\\A1.owl";
//		String path = "C:\\Users\\goche\\Desktop\\Documents\\PhD\\Protege\\Models\\Academic_example_v1\\A2.owl";
//		String path = "C:\\Users\\goche\\Desktop\\Documents\\PhD\\Protege\\Models\\Toy_ontology\\Toy_example.owl";
	    OWLOntology ontology = owlUtils.loadOntology(path);
	    
	    for (OWLAxiom ax : ontology.getAxioms()){
	    	System.out.println(ax);
	    }
	    
	    // Get ontology IRI:
	    IRI ontologyIRI = owlUtils.getOntologyIRI(ontology);
		
	    // Get data factory:
	    OWLDataFactory dataFactory = owlUtils.createDataFactory();
	    
	    // Create the reasoner:
        OWLReasoner reasoner = owlUtils.getReasoner(ontology);
	    
        OWLClass owlThing = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix4, "Thing");
        OWLClass owlNothing = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix4, "Nothing");
        
        // ---
        
        // Synchronize the reasoner and save all inferences in a new ontology:
        owlUtils.SyncReasoner(reasoner);
        
        // ---------- END OF INITIALIZATION: ---------- //
        
        /** 
	     *  Tests: 
	     */
        
        //////////        //////////        //////////        //////////        //////////        //////////        //////////
        // ---------- PROBABILITY ASSIGNMENT: ---------- //
        
        
        
        // RETRIEVE ALL AXIOMS FROM THE ONTOLOGY:
//        Set<OWLAxiom> axioms = owlFunctions.getAllAxiomsFromOntology(ontology);
        
        // RETRIEVE ALL CLASSES (CONCEPT NAMES) IN THE ONTOLOGY (FROM Nc):
//        Set<OWLClass> Nc = ontology.getClassesInSignature();
        
//        OWLClassExpression concept1 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Caprina");
//        OWLClassExpression concept2 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix3, "HomemadeVegetarianPizza");
        
//        OWLClassExpression concept1 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Q");
//        OWLClassExpression concept2 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "W2");
        
//        OWLClassExpression concept1 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Professor");
//        OWLClassExpression concept2 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Researcher");
        
//        OWLClassExpression concept1 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Toy1");
//        OWLClassExpression concept2 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Toy3");
        
//        Set<OWLClass> Sub_concept1 = owlFunctions.getAllSubClassesOfConceptViaReasoning(ontology, reasoner, concept1);
//        Set<OWLClass> Sub_concept2 = owlFunctions.getAllSubClassesOfConceptViaReasoning(ontology, reasoner, concept2);
		
        // FIND THE CARDINALITIES OF Sub(C) and Nc:
//        int cardinality_Sub_C = Sub_concept1.size();
//        int cardinality_Sub_C2 = Sub_concept2.size();
//        int cardinality_Nc = Nc.size();
        
        // FIND THE PROBABILITY OF CONCEPT1 [P(C)]:
//        float probability_C = (float) cardinality_Sub_C / (float) cardinality_Nc;
//        float probability_C2 = (float) cardinality_Sub_C2 / (float) cardinality_Nc;
        
        // ASSIGN PROBABILITIES TO ALL CONCEPTS:
//        Map<OWLClass, Float> PMF = assignProbabilities(ontology, reasoner);
        
//        Node<Object> root = constructTree(ontology, dataFactory, reasoner, PMF);
        
        // PRINT TREE:
//        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		System.out.println("---------- TREE STRUCTURE: ----------");
//		boolean[] flag = new boolean[Nc.size()];
//	    Arrays.fill(flag, true);
//		printNTree(root, flag, 0, false);
//		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
//		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		
		// FIND ALL PATHS IN THE TREE OF INFERENCES:
//		List<List<OWLClass>> pathsToConcepts = findPathsToAConcept(root, owlNothing, (OWLClass) concept1);
		
//		float prob_Professor = findProbabilityOfAConcept((OWLClass) concept1, pathsToConcepts, PMF, owlNothing).get(concept1);
//		float prob_Researcher = findProbabilityOfAConcept((OWLClass) concept2, pathsToConcepts, PMF, owlNothing).get(concept2);
		
//		double H_Professor = findEntropyOfAConcept(prob_Professor);
//		double H_Researcher = findEntropyOfAConcept(prob_Researcher);
		
//		OWLClassExpression C1 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "PhD");
//		float prob_C1 = findProbabilityOfAConcept((OWLClass) C1, pathsToConcepts, PMF, owlNothing).get(C1);
		
		// FIND HYPOTHESYS SET H:
//		Set<OWLClass> H = findHypothesys(concept1, concept2, ontology, reasoner);
		
		/**
		 * TESTS WITH HOMOMORPHISMS:
		 */
        // TODO: CONTINUE WORK
        
		OWLClassExpression A = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Professor");
        OWLClassExpression B = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Researcher");
		
//		constructConceptDescriptionTree((OWLClass) A, ontology, owlThing);
		constructConceptDescriptionGraph((OWLClass) A, ontology);
		constructConceptDescriptionGraph((OWLClass) B, ontology);
        
//		float prob_H = (float) 0.0;
//		
//		float sim = similarityMeasure_1(prob_Caprina, prob_HomemadeVegetarianPizza, prob_H);
		
        // ---------- END OF PROBABILITY ASSIGNMENT: ---------- //
        
        
        
        //////////        //////////        //////////        //////////        //////////        //////////        //////////
		// ---------- METHOD FOR EXPLAINING SEMANTIC MATCHING: ---------- //
        
        
//		// DEFINE WHICH CLASS TO GET:
//		OWLClass class1 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix3, "HomemadeVegetarianPizza");
//		OWLClass class2 = owlFunctions.getClassFromOntology(dataFactory, owlUtils.prefix1, "Caprina");
//		
//		// FOR THE ABOVE DEFINED CLASS, RETURN THE SET OF ALL EquivalentTo expressions:
//		Set<OWLEquivalentClassesAxiom> equivalentClasses_class1 = owlFunctions.getEquivalentClassesFromOntology(ontology, class1);
//		Set<OWLEquivalentClassesAxiom> equivalentClasses_class2 = owlFunctions.getEquivalentClassesFromOntology(ontology, class2);
//		
//		// CHOOSE THE ONE THAT WE ARE LOOKING FOR EquivalentTo DESCRIPTION:
//		OWLEquivalentClassesAxiom HVP = Functions.getNthElementOfSet(equivalentClasses_class1, 0);
//		OWLEquivalentClassesAxiom Caprina = Functions.getNthElementOfSet(equivalentClasses_class2, 0);
//		
//		// EXTRACT THE SETS OF ALL CONCEPTS AND ROLES FROM THE CONCEPT DESCRIPTION:
//		Set<OWLClass> concepts_HVP = HVP.getClassesInSignature();
//		Set<OWLObjectProperty> roles_HVP = HVP.getObjectPropertiesInSignature();
//		Set<OWLClass> concepts_Caprina = Caprina.getClassesInSignature();
//		Set<OWLObjectProperty> roles_Caprina = Caprina.getObjectPropertiesInSignature();
//		
//		
//		// EXTRACT THE CLASS EXPRESSIONS FROM THE CONCEPT DESCRIPTION:
//		Set<OWLClassExpression> classExpressions_HVP = HVP.getClassExpressions();
//		OWLClassExpression concept_name_HVP = Functions.getNthElementOfSet(classExpressions_HVP, 0);
//		OWLClassExpression concept_description_HVP = Functions.getNthElementOfSet(classExpressions_HVP, 1);
//		Set<OWLClassExpression> concept_description_HVP_Set = Functions.getNthElementOfSet(classExpressions_HVP, 1).asConjunctSet();
//		
//		Set<OWLClassExpression> classExpressions_Caprina = Caprina.getClassExpressions();
//		OWLClassExpression concept_name_Caprina = Functions.getNthElementOfSet(classExpressions_Caprina, 0);
//		OWLClassExpression concept_description_Caprina = Functions.getNthElementOfSet(classExpressions_Caprina, 1);
//		Set<OWLClassExpression> concept_description_Caprina_Set = Functions.getNthElementOfSet(classExpressions_Caprina, 1).asConjunctSet();
		
		// ---------- END OF METHOD FOR EXPLAINING SEMANTIC MATCHING: ---------- //
		
		
		
        //////////        //////////        //////////        //////////        //////////        //////////        //////////
		// ---------- OUTPUTS: ---------- //
		
//		System.out.println();
//		System.out.println("----------------------------------------------------------------------");
//		System.out.println("//////////        //////////        //////////        //////////        //////////        //////////        //////////");
//	    System.out.println("// ---------- OUTPUTS FROM PROBABILITY ASSIGNMENT: ---------- //");
////	    System.out.println();
////	    System.out.println("|Sub(C)| = " + cardinality_Sub_C);
////	    System.out.println("|O| = " + cardinality_Nc);
////	    System.out.println("=> P(C) = |Sub(C)| / |O| = " + probability_C);
////	    System.out.println();
//	    System.out.println("----------------------------------------------------------------------");
//	    System.out.println();
//	    System.out.println("PROBABILITY MASS FUNCTION (PMF): ");
//	    System.out.println();
//	    Functions.printMap(PMF);
//	    System.out.println();
//	    System.out.println("----------------------------------------------------------------------");
//	    System.out.println("OWL Manager = " + manager);
//	    System.out.println("Ontology = " + ontology);
//	    System.out.println("Ontology IRI = " + ontologyIRI);
//	    System.out.println("====================================================================================================");
//	    System.out.println("axioms = " + axioms.size());
//	    Functions.printAxioms(axioms);
//	    System.out.println("Reasoner = " + reasoner.getReasonerName());
//	    System.out.println("====================================================================================================");
//	    System.out.println("class1 = " + class1);
//	    System.out.println("class2 = " + class2);
//	    System.out.println("conjunction = " + conjunction);
//	    System.out.println("====================================================================================================");
//	    System.out.println("myClass = " + myClass);
//	    Functions.printSetOfEquivalentClassesAxioms(equivalentClasses);
//	    System.out.println("====================================================================================================");
//	    System.out.println("NESTED CLASS EXPRESSIONS: ");
//	    Functions.printSetOfClassExpressions(HVP.getNestedClassExpressions());
//	    System.out.println("----------");
//	    System.out.println("CONCEPTS: ");
//	    Functions.printSet(HVP.getClassesInSignature());
//	    System.out.println("----------");
//	    System.out.println("ROLES: ");
//	    Functions.printSet(HVP.getObjectPropertiesInSignature());
//	    System.out.println("----------");
//	    System.out.println("CLASS EXPRESSIONS: ");
//	    Functions.printSet(HVP.getClassExpressions());
//	    System.out.println("----------");
//	    System.out.println("//////////        //////////        //////////        //////////        //////////        //////////        //////////");
//	    System.out.println("// ---------- OUTPUTS FROM METHOD FOR EXPLAINING SEMANTIC MATCHING: ---------- //");
//	    System.out.println("----------------------------------------------------------------------");
//	    System.out.println();
//	    System.out.println("| CONCEPTS IN THE SEMANTIC MATCHING FORMULA: |");
//	    System.out.println();
//	    System.out.println("C1 := " + Functions.clearPrefixes(concept_name_HVP));
//	    System.out.println("C2 := " + Functions.clearPrefixes(concept_name_Caprina));
//	    System.out.println();
//	    System.out.println("----------------------------------------------------------------------");
//	    System.out.println();
//	    System.out.println("| CONCEPT DESCRIPTION (SET) HVP: |");
//	    System.out.println();
//	    Functions.printSet(concept_description_HVP_Set);
//	    System.out.println();
//	    System.out.println("----------------------------------------------------------------------");
//	    System.out.println();
//	    System.out.println("| CONCEPT DESCRIPTION (SET) Caprina: |");
//	    System.out.println();
//	    Functions.printSet(concept_description_Caprina_Set);
//	    System.out.println();
	}
}
