package com.xai.methods;

import java.util.HashSet;
import java.util.Set;

public class MethodFunctionsAndDefinitions {
	
	/**
	 * For tree T, T.N(v) := {y in T.V | <x, y> in T.E}.
	 * 
	 * @param v
	 * 
	 * @return N(v)
	 */
	public static Set<Integer> N(DescriptionTree T, int v) {
		
		if (T.tree.containsKey(v)) {
			Set<Integer> N = new HashSet<Integer>(T.tree.get(v));
			
			return N;
		} else {
			Set<Integer> N = new HashSet<Integer>();
			
			return N;
		}
	}
}
