package com.xai.methods;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

//import org.semanticweb.HermiT.ReasonerFactory;
//import org.semanticweb.owl.explanation.api.*;
import org.semanticweb.owlapi.model.*;
//import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

public class Explanations {
	
	public OWLOntology ontology;
	public OWLAxiom axiom;
	
	/**
	 * Constructor for class {@link Explanations}
	 * 
	 * @param ontology
	 * @param axiom
	 * 
	 * @return 
	 */
	public Explanations(OWLOntology ontology, OWLAxiom axiom) {
		this.ontology = ontology;
		this.axiom = axiom;
	}
	
	/**
	 * Function that checks whether the axiom is entailed or not entailed.
	 * 
	 * @param
	 * 
	 * @return true / false
	 */
	public boolean isEntailed() {
		// TODO
		
		return true;
	}
	
	/**
	 * Function that returns the explanations for an entailment.
	 * 
	 * @param numberOfExplanations
	 * 
	 * @return expl
	 */
//	public Set<Explanation<OWLAxiom>> getExplanationsEntailment(int numberOfExplanations) {
//		OWLReasonerFactory reasonerFactory = new ReasonerFactory();
//		
//		ExplanationGeneratorFactory<OWLAxiom> genFac = ExplanationManager.createExplanationGeneratorFactory(reasonerFactory);
//		
//		ExplanationGenerator<OWLAxiom> gen = genFac.createExplanationGenerator(this.ontology);
//		
//		Set<Explanation<OWLAxiom>> expl = gen.getExplanations(this.axiom, numberOfExplanations);
//		
//		return expl;
//	}
	
	/**
	 * Function that returns the explanations for a non-entailment.
	 * 
	 * @param 
	 * 
	 * @return expl
	 * @throws OWLOntologyCreationException 
	 */
	public static Set<Set<OWLAxiom>> getExplanationsNonEntailment(int numberOfExplanations) throws OWLOntologyCreationException {
		
		Set<Set<OWLAxiom>> Hypotheses = new HashSet<Set<OWLAxiom>>();
		
		// TODO: Ivan: Translate C1 and C2 to trees. eta := C1 SubClassOf C2 => Get the trees for C1 and C2:
		DescriptionTree T1 = null;
		DescriptionTree T2 = null;
		
		// Generate Hypotheses:
		XeNON xenon = new XeNON(T1, T2);
		Map i = xenon.subtreeIsomorphisms();
		Set<Set<String>> H = xenon.constructHypotheses(i, "SubClassOf");
		
		// TODO: Both: Construct hypotheses:
		for (Set<String> h : H) {
			
			// make new empty ontology o
			// ...
			
			for (String a : h) {
				// declare class and property names in o
				// ...
				
				// call addedAxiom = parseClassExpression(a) and make it an OWLAxiom
				// ...
				
				// add the addedAxiom in o:
				// ...
			}
			
			// save the ontology o in a local folder (// Remember the folder in which the hypotheses are saved.)
			// ...
		}
		
		
		// TODO: Both: Find the union of this.ontology with each hypothesis:
		
			// TODO: Both: generate for each of that union the justifications for this.axiom.
		
		return Hypotheses;
	}
	
	
}
