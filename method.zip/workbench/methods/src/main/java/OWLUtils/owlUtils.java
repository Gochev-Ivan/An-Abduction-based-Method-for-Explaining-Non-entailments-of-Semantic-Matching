package OWLUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.coode.owlapi.manchesterowlsyntax.ManchesterOWLSyntaxEditorParser;
import org.semanticweb.HermiT.ReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.expression.OWLEntityChecker;
import org.semanticweb.owlapi.expression.ShortFormEntityChecker;
import org.semanticweb.owlapi.formats.FunctionalSyntaxDocumentFormat;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.util.BidirectionalShortFormProvider;
import org.semanticweb.owlapi.util.BidirectionalShortFormProviderAdapter;
import org.semanticweb.owlapi.util.InferredAxiomGenerator;
import org.semanticweb.owlapi.util.InferredEquivalentClassAxiomGenerator;
import org.semanticweb.owlapi.util.InferredOntologyGenerator;
import org.semanticweb.owlapi.util.InferredSubClassAxiomGenerator;
import org.semanticweb.owlapi.util.ShortFormProvider;
import org.semanticweb.owlapi.util.SimpleShortFormProvider;

public class owlUtils {
	
//	 public static String prefix1 = "http://www.co-ode.org/ontologies/pizza/pizza.owl#";
	 public static String prefix1 = "http://www.semanticweb.org/goche/ontologies/2021/9/untitled-ontology-6#";
	 public static String prefix2 = "http://www.w3.org/2004/02/skos/core#";
	 public static String prefix3 = "http://www.co-ode.org/ontologies/pizza#";
	 public static String prefix4 = "http://www.w3.org/2002/07/owl#";
	 public static OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
	 public static OWLOntology ontology;
	 
	 /**
	  * Function that returns the reasoner.
	  * 
	  * @return
	  */
     public static OWLReasoner getReasoner(OWLOntology onto) {
    	 OWLReasonerFactory reasonerFactory = new ReasonerFactory();
         OWLReasoner reasoner = reasonerFactory.createReasoner(onto);
         
    	 return reasoner;
     }
     
     
     /**
      * Function that synchronizes the reasoner.
      * 
      * @param reasoner
      * @throws OWLOntologyCreationException 
      */
     public static void SyncReasoner(OWLReasoner reasoner) throws OWLOntologyCreationException {
    	 reasoner.precomputeInferences(InferenceType.values());
 		
         // Synchronize the reasoner and save all original knowledge + inferences in a new ontology:
         // To generate an inferred ontology we use implementations of inferred axiom generators
     	List<InferredAxiomGenerator<? extends OWLAxiom>> gens = new ArrayList<InferredAxiomGenerator<? extends OWLAxiom>>();
     	gens.add(new InferredSubClassAxiomGenerator());
     	gens.add(new InferredEquivalentClassAxiomGenerator());
     	
     	// Put the inferred axioms into a fresh empty ontology.
     	OWLOntologyManager outputOntologyManager = OWLManager.createOWLOntologyManager();
     	OWLOntology infOnt = outputOntologyManager.createOntology();
     	InferredOntologyGenerator iog = new InferredOntologyGenerator(reasoner,
     			gens);
     	iog.fillOntology(outputOntologyManager.getOWLDataFactory(), infOnt);
     	
     	// Save the inferred ontology.
     	try {
     		
//     		String new_path = "C:\\Users\\Ivan\\Desktop\\Backup_08-06-2023\\Documents\\PhD\\Protege\\Models\\Pizza_ontology\\new_inference_1.owl";
     		String new_path = "C:\\Users\\Ivan\\Desktop\\saved-onto-inferred.owl";
 			outputOntologyManager.saveOntology(infOnt,
 					new FunctionalSyntaxDocumentFormat(),
 					IRI.create((new File(new_path).toURI())));
 					// IRI.create((new File("C:\\Users\\goche\\Desktop\\Documents\\PhD\\Protege\\Models\\Pizza_ontology\\pizza-inferred.owl").toURI())));
 		} catch (OWLOntologyStorageException e) {
 			e.printStackTrace();
 		}
     }
     
     
	 /**
	  * Function which creates an ontology manager.
	  * 
	  * @return
	  */
	 public static OWLOntologyManager createOntologyManager() {
	 	 return manager;
	 }
	 
	 
	 /**
	  * Function that creates and returns the data factory.
	  * 
	  * @return
	  */
	 public static OWLDataFactory createDataFactory() {
	 	 return manager.getOWLDataFactory();
	 }
	 
	 
	 /**
	  * Function which loads the ontology from a given document file.
	  * 
	  * @param path
	  * @return
	  * @throws OWLOntologyCreationException 
	  */
	 public static OWLOntology loadOntology(String path) throws OWLOntologyCreationException {
	 	 // Load file:
	 	 
	 	 File file = new File(path);
	 	 
	 	 // Loading the ontology:
	 	 ontology = manager.loadOntologyFromOntologyDocument(file);
	 	 
	 	 return ontology;
	 }
	 
	 
	 /**
	  * Function which returns the ontology IRI from a given ontology.
	  * 
	  * @param ontology
	  * @return
	  */
	 public static IRI getOntologyIRI(OWLOntology ontology) {
	 	 return ontology.getOntologyID().getOntologyIRI().get();
	 }
	 
	 /**
	  * Function which parses a string into an ontology axiom.
	  * 
	  * @param ontology
	  * @param manager
	  * @param dataFactory
	  * @param classExpressionString
	  * 
	  * @return parser.parseAxiom()
	  */
	 public static OWLAxiom parseClassExpression(OWLOntology ontology, OWLOntologyManager manager, OWLDataFactory dataFactory, String classExpressionString) {
	        
	        @SuppressWarnings("deprecation")
			ManchesterOWLSyntaxEditorParser parser = new ManchesterOWLSyntaxEditorParser(dataFactory, classExpressionString);
	        parser.setDefaultOntology(ontology);
	        
	        Set<OWLOntology> importsClosure = ontology.getImportsClosure();
	        
	        ShortFormProvider shortFormProvider = new SimpleShortFormProvider();
	        BidirectionalShortFormProvider bidiShortFormProvider = new BidirectionalShortFormProviderAdapter(manager, importsClosure, shortFormProvider);
			OWLEntityChecker entityChecker = new ShortFormEntityChecker(bidiShortFormProvider);
			
	        parser.setOWLEntityChecker(entityChecker);
	        
	        return parser.parseAxiom();
	    }
}
