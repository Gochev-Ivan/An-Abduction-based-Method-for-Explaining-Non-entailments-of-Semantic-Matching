package Trees;

import java.util.LinkedList;
import java.util.List;

public class Node<T> {
	
	public T value; // for now node values are int
	
	public T nodeName;
	
	@SuppressWarnings("rawtypes")
	public List<Node> children = new LinkedList<>();
	@SuppressWarnings("rawtypes")
	public List<Node> parents = new LinkedList<>();
	
	public Node(@SuppressWarnings("rawtypes") List<Node> parents) {
		this.parents = parents;
	}
	
	public Node(T value) {
		this.value = value;
	}
	
	public Node(T nodeName, T value, @SuppressWarnings("rawtypes") List<Node> children) {
		this.nodeName = nodeName;
		this.value = value;
		this.children = children;
	}
}
